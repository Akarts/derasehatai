import 'dart:convert';
import 'dart:typed_data';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

import '../config.dart';
import '../models/triage_result.dart';
import 'firestore_service.dart';

/// Google Gemini AI triage service.
///
/// HOW TO ENABLE THE REAL AI:
/// 1. Get a key at https://aistudio.google.com/app/apikey
/// 2. Replace the placeholder below (never commit a real key).
/// 3. In production, call Gemini from your own backend / Firebase
///    Function instead of from the app, so the key is not in the APK.
///
/// When no key is set, [triage] uses a safe local mock so the whole
/// Patient flow still works end-to-end offline.
class GeminiService {
  GeminiService({String apiKey = geminiApiKey}) : _apiKey = apiKey;

  // Set in lib/config.dart, or in the app via Admin > Gemini API Key.
  static const String geminiApiKey = AppConfig.geminiApiKey;

  /// Current model (Nov 2026). gemini-1.5-flash is retired by
  /// Google and returns 404 — that was why every call failed
  /// silently and the app fell back to the demo mock.
  static const String modelName = 'gemini-3.5-flash';

  /// The last Gemini error, if any — shown by the Admin "Test AI"
  /// button so a bad key / model / quota is visible, not silent.
  static String? lastError;

  final String _apiKey;

  bool get isConfigured =>
      _apiKey.isNotEmpty && _apiKey != 'YOUR_GEMINI_API_KEY';

  Future<TriageResult> triage(String symptoms, {int age = 0}) async {
    // Firebase mode: Gemini runs in a Cloud Function, so the API
    // key is never in the app. The function is in functions/index.js.
    if (FirestoreService.isConfigured) {
      try {
        final callable = FirebaseFunctions.instance
            .httpsCallable('triageSymptoms');
        final result = await callable.call({
          'symptoms': symptoms,
          'age': age,
        });
        final data = result.data as Map;
        return TriageResult(
          summary: (data['summary'] as String?) ?? symptoms,
          suggestedSpecialty:
              (data['specialty'] as String?) ?? 'General Physician',
          confidencePercent:
              (data['confidence'] as num?)?.toInt() ?? 70,
          followUpQuestions: (data['questions'] as List?)
                  ?.map((q) => q.toString())
                  .toList() ??
              const ['Kab se takleef hai?', 'Dard kitna shadeed hai?'],
          isEmergency: data['isEmergency'] as bool? ?? false,
        );
      } catch (_) {
        // Cloud Function not deployed yet — fall through to the
        // direct-key / mock path below.
      }
    }
    if (!isConfigured) {
      // Offline demo path — no network, no key needed.
      await Future<void>.delayed(const Duration(milliseconds: 800));
      return _mockTriage(symptoms);
    }
    try {
      final model = GenerativeModel(
        model: modelName,
        apiKey: _apiKey,
      );
      final prompt = '''
You are a medical triage assistant for a clinic booking app in Pakistan.
The patient wrote (in Urdu, Roman Urdu or English): "$symptoms".
Patient age: $age.

Reply in exactly this format, in simple English:
SUMMARY: <one short summary of the problem>
SPECIALTY: <one of: General Physician, Pediatrician, Gastroenterologist, Dermatologist, Dentist, Gynecologist, Orthopedic Surgeon>
CONFIDENCE: <0-100>
QUESTION 1: <a useful follow-up question>
QUESTION 2: <a useful follow-up question>
EMERGENCY: <yes or no — yes only for chest pain, breathing trouble, unconsciousness, heavy bleeding, or a broken bone>

Do NOT give a diagnosis. Do NOT prescribe medicine. This is only to
choose the right specialist.
''';
      final response = await model.generateContent([Content.text(prompt)]);
      lastError = null;
      return _parseGeminiResponse(response.text ?? '', symptoms);
    } catch (e) {
      // If Gemini fails (no internet, bad key, quota, retired
      // model), remember the error and fall back to the local mock
      // so the patient is never stuck — but the result is marked
      // as a demo answer, so it is never mistaken for real AI.
      lastError = e.toString();
      return _mockTriage(symptoms);
    }
  }

  /// Read a payment screenshot with Gemini Vision and extract the
  /// Transaction ID (plus amount / method / date when visible).
  /// Returns null when Gemini is not configured or nothing is found.
  /// The patient never types a Transaction ID — this is the only
  /// way it is filled in.
  Future<TransactionDetails?> extractTransactionDetails(
    Uint8List imageBytes,
  ) async {
    // Firebase mode: Gemini Vision runs in a Cloud Function.
    if (FirestoreService.isConfigured) {
      try {
        final callable = FirebaseFunctions.instance
            .httpsCallable('extractTransaction');
        final result = await callable.call({
          'imageBase64': base64Encode(imageBytes),
        });
        final data = result.data;
        if (data == null) return null;
        final map = data as Map;
        return TransactionDetails(
          transactionId: (map['transactionId'] as String?) ?? '',
          amount: (map['amount'] as String?) ?? '',
          method: (map['method'] as String?) ?? '',
          date: (map['date'] as String?) ?? '',
        );
      } catch (_) {
        return null;
      }
    }
    if (!isConfigured) return null;
    try {
      final model = GenerativeModel(
        model: modelName,
        apiKey: _apiKey,
      );
      final response = await model.generateContent([
        Content.multi([
          TextPart(
            'This is a payment receipt screenshot from JazzCash, '
            'Easypaisa or a bank in Pakistan. Read it and reply in '
            'exactly this format, one item per line, nothing else:\n'
            'TRANSACTION_ID: <the transaction / reference / TID number, or NOT_FOUND>\n'
            'AMOUNT: <the amount paid, e.g. Rs. 1600, or NOT_FOUND>\n'
            'METHOD: <JazzCash, Easypaisa or Bank Transfer, or NOT_FOUND>\n'
            'DATE: <the payment date if shown, or NOT_FOUND>',
          ),
          DataPart('image/jpeg', imageBytes),
        ]),
      ]);
      final text = response.text ?? '';
      String pick(String label) {
        for (final line in text.split('\n')) {
          if (line.toUpperCase().startsWith(label)) {
            final value = line.substring(label.length).trim();
            return value.toUpperCase() == 'NOT_FOUND' ? '' : value;
          }
        }
        return '';
      }

      final id = pick('TRANSACTION_ID:');
      if (id.isEmpty) return null;
      return TransactionDetails(
        transactionId: id,
        amount: pick('AMOUNT:'),
        method: pick('METHOD:'),
        date: pick('DATE:'),
      );
    } catch (_) {
      return null;
    }
  }

  TriageResult _parseGeminiResponse(String text, String fallbackSymptoms) {
    String pick(String label) {
      for (final line in text.split('\n')) {
        if (line.toUpperCase().startsWith(label)) {
          return line.substring(label.length).trim();
        }
      }
      return '';
    }

    final specialty = pick('SPECIALTY:');
    final summary = pick('SUMMARY:');
    final confidence =
        int.tryParse(pick('CONFIDENCE:').replaceAll('%', '')) ?? 70;
    final questions = <String>[
      pick('QUESTION 1:'),
      pick('QUESTION 2:'),
    ].where((q) => q.isNotEmpty).toList();

    return TriageResult(
      summary: summary.isNotEmpty ? summary : fallbackSymptoms,
      suggestedSpecialty:
          specialty.isNotEmpty ? specialty : 'General Physician',
      confidencePercent: confidence.clamp(0, 100),
      followUpQuestions: questions.isEmpty
          ? const ['Kab se takleef hai?', 'Dard kitna shadeed hai?']
          : questions,
      isEmergency:
          pick('EMERGENCY:').toLowerCase().startsWith('y'),
    );
  }

  /// Keyword triage used when Gemini is not configured.
  /// This is a demo helper only — it does not diagnose.
  TriageResult _mockTriage(String symptoms) {
    final s = symptoms.toLowerCase();
    final isEmergency = s.contains('seene') ||
        s.contains('chest') ||
        s.contains('saans') ||
        s.contains('breath') ||
        s.contains('behosh');

    String specialty = 'General Physician';
    if (s.contains('haddi') ||
        s.contains('tut') ||
        s.contains('fracture') ||
        s.contains('bone') ||
        s.contains('ghutna') ||
        s.contains('kamar') ||
        s.contains('joint')) {
      specialty = 'Orthopedic Surgeon';
    } else if (s.contains('pait') ||
        s.contains('stomach') ||
        s.contains('pait dard') ||
        s.contains('gas') ||
        s.contains('dast') ||
        s.contains('diarrhea')) {
      specialty = 'Gastroenterologist';
    } else if (s.contains('daant') ||
        s.contains('tooth') ||
        s.contains('dental')) {
      specialty = 'Dentist';
    } else if (s.contains('jild') ||
        s.contains('skin') ||
        s.contains('kharish') ||
        s.contains('daane') ||
        s.contains('rash')) {
      specialty = 'Dermatologist';
    } else if (s.contains('bacha') ||
        s.contains('child') ||
        s.contains('baby') ||
        s.contains('beta') ||
        s.contains('beti')) {
      specialty = 'Pediatrician';
    }

    return TriageResult(
      summary: symptoms.trim(),
      suggestedSpecialty: specialty,
      confidencePercent: 92,
      followUpQuestions: const [
        'Ye takleef kab se hai?',
        'Kya aap ne koi dawai li hai?',
      ],
      isEmergency: isEmergency,
      isDemo: true,
    );
  }
}

/// What AI read from a payment screenshot.
class TransactionDetails {
  const TransactionDetails({
    required this.transactionId,
    this.amount = '',
    this.method = '',
    this.date = '',
  });

  final String transactionId;
  final String amount;
  final String method;
  final String date;
}
