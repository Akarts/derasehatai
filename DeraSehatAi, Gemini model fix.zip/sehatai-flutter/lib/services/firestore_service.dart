import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../models/booking.dart';
import '../models/doctor.dart';

/// Firestore / Firebase wiring.
///
/// When Firebase is configured (google-services.json added, see
/// firebase-setup-guide.md), doctors, settings and bookings live
/// in Firestore and are shared by every phone. When it is NOT
/// configured, [BookingProvider] falls back to its local
/// SharedPreferences data — so the app still works offline for
/// testing. Nothing here throws when Firebase is absent; callers
/// check [isConfigured] first.
class FirestoreService {
  static const String doctorsCollection = 'doctors';
  static const String bookingsCollection = 'bookings';
  static const String settingsDoc = 'settings/app';
  static const String adminsCollection = 'admins';

  /// Set by main() after Firebase.initializeApp() succeeds.
  static bool isConfigured = false;

  FirebaseFirestore get _db => FirebaseFirestore.instance;

  // ----- Doctors (shared by all phones) -----

  Stream<List<Doctor>> streamDoctors() => _db
      .collection(doctorsCollection)
      .snapshots()
      .map((snap) => snap.docs
          .map((d) => Doctor.fromJson({...d.data(), 'id': d.id}))
          .toList());

  Future<List<Doctor>> fetchDoctors() async {
    final snap = await _db.collection(doctorsCollection).get();
    return snap.docs
        .map((d) => Doctor.fromJson({...d.data(), 'id': d.id}))
        .toList();
  }

  Future<void> saveDoctor(Doctor doctor) async {
    await _db
        .collection(doctorsCollection)
        .doc(doctor.id)
        .set(doctor.toJson());
  }

  Future<void> deleteDoctor(String id) async {
    await _db.collection(doctorsCollection).doc(id).delete();
  }

  /// Seed the 6 sample doctors once, only if the collection is empty.
  Future<void> seedDoctorsIfEmpty() async {
    final snap = await _db.collection(doctorsCollection).limit(1).get();
    if (snap.docs.isNotEmpty) return;
    final batch = _db.batch();
    for (final d in sampleDoctors) {
      batch.set(_db.collection(doctorsCollection).doc(d.id), d.toJson());
    }
    await batch.commit();
  }

  // ----- Settings (payment accounts — shared) -----

  Future<Map<String, String>> fetchPaymentAccounts() async {
    final doc = await _db.doc(settingsDoc).get();
    final data = doc.data();
    if (data == null) return {};
    final accounts = data['paymentAccounts'];
    if (accounts is! Map) return {};
    return accounts.map(
      (k, v) => MapEntry(k.toString(), v.toString()),
    );
  }

  Future<void> savePaymentAccounts(Map<String, String> accounts) async {
    await _db.doc(settingsDoc).set(
      {'paymentAccounts': accounts},
      SetOptions(merge: true),
    );
  }

  // ----- Bookings (shared: patient phone -> Assistant phone) -----

  Stream<List<Booking>> streamBookings() => _db
      .collection(bookingsCollection)
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((snap) => snap.docs
          .map((d) => Booking.fromJson({...d.data(), 'id': d.id}))
          .toList());

  Future<void> saveBooking(Booking booking) async {
    await _db
        .collection(bookingsCollection)
        .doc(booking.id)
        .set(booking.toJson(), SetOptions(merge: true));
  }

  Future<void> updateBookingStatus(
    String bookingId,
    BookingStatus status, {
    int? tokenNumber,
  }) async {
    await _db.collection(bookingsCollection).doc(bookingId).update({
      'status': status.name,
      if (tokenNumber != null) 'tokenNumber': tokenNumber,
    });
  }

  // ----- Payment screenshot (Storage, URL only in Firestore) -----

  Future<String> uploadPaymentScreenshot(String localPath) async {
    final fileName =
        'payments/${DateTime.now().millisecondsSinceEpoch}.jpg';
    final ref = FirebaseStorage.instance.ref(fileName);
    await ref.putFile(File(localPath));
    return ref.getDownloadURL();
  }

  // ----- Admin check -----

  /// True when this Firebase user is listed as an admin.
  Future<bool> isAdminUser(String uid) async {
    final doc = await _db.collection(adminsCollection).doc(uid).get();
    return doc.exists;
  }
}
