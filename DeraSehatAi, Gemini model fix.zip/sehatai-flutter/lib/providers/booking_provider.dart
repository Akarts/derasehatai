import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';
import '../models/booking.dart';
import '../models/doctor.dart';
import '../services/firestore_service.dart';

/// App state (Provider). Doctors, payment accounts and the Gemini
/// key are saved on the phone (SharedPreferences) so the Admin
/// panel's changes survive restarts. Bookings are still in-memory
/// for this MVP — in production, replace them with Firestore
/// streams (see FirestoreService).
class BookingProvider extends ChangeNotifier {
  BookingProvider() {
    _loadPersisted();
    _startFirebaseSync();
  }

  final FirestoreService _firestore = FirestoreService();
  StreamSubscription<List<Doctor>>? _doctorsSub;
  StreamSubscription<List<Booking>>? _bookingsSub;

  /// True when Firebase is configured — doctors, settings and
  /// bookings are then shared by every phone. Otherwise the app
  /// uses the local data saved on this phone only.
  bool get isFirebaseMode => FirestoreService.isConfigured;

  void _startFirebaseSync() {
    if (!FirestoreService.isConfigured) return;
    _doctorsSub = _firestore.streamDoctors().listen((doctors) {
      if (doctors.isNotEmpty) {
        _doctors = doctors;
        notifyListeners();
      }
    }, onError: (_) {});
    _bookingsSub = _firestore.streamBookings().listen((bookings) {
      if (bookings.isNotEmpty) {
        _bookings
          ..clear()
          ..addAll(bookings);
        notifyListeners();
      }
    }, onError: (_) {});
  }

  @override
  void dispose() {
    _doctorsSub?.cancel();
    _bookingsSub?.cancel();
    super.dispose();
  }

  static const _kDoctors = 'dera_doctors_json';
  static const _kAccounts = 'dera_payment_accounts';
  static const _kGeminiKey = 'dera_gemini_api_key';

  List<Doctor> _doctors = List<Doctor>.from(sampleDoctors);

  List<Doctor> get doctors => List<Doctor>.unmodifiable(_doctors);

  Map<String, String> paymentAccounts = <String, String>{
    'JazzCash': 'JazzCash: 03XX-XXXXXXX (DeraSehatAi Clinic)',
    'Easypaisa': 'Easypaisa: 03XX-XXXXXXX (DeraSehatAi Clinic)',
    'Bank Transfer': 'Bank: XXXX-XXXX-XXXX (DeraSehatAi Clinic)',
  };

  String _geminiKeyOverride = '';

  /// The Gemini key actually in use: Admin-saved key first,
  /// otherwise the one in lib/config.dart.
  String get effectiveGeminiApiKey => _geminiKeyOverride.isNotEmpty
      ? _geminiKeyOverride
      : AppConfig.geminiApiKey;

  bool get isGeminiConfigured =>
      effectiveGeminiApiKey.isNotEmpty &&
      effectiveGeminiApiKey != 'YOUR_GEMINI_API_KEY';

  Future<void> _loadPersisted() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final doctorsJson = prefs.getString(_kDoctors);
      if (doctorsJson != null && doctorsJson.isNotEmpty) {
        final loaded = Doctor.listFromJson(doctorsJson);
        if (loaded.isNotEmpty) _doctors = loaded;
      }
      for (final method in paymentAccounts.keys.toList()) {
        final saved = prefs.getString('$_kAccounts:$method');
        if (saved != null && saved.isNotEmpty) {
          paymentAccounts[method] = saved;
        }
      }
      _geminiKeyOverride = prefs.getString(_kGeminiKey) ?? '';
      if (isFirebaseMode) {
        final remote = await _firestore.fetchPaymentAccounts();
        for (final entry in remote.entries) {
          paymentAccounts[entry.key] = entry.value;
        }
      }
      notifyListeners();
    } catch (_) {
      // First run / no storage yet — keep the sample data.
    }
  }

  Future<void> _saveDoctors() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kDoctors, Doctor.listToJson(_doctors));
  }

  void addDoctor(Doctor doctor) {
    _doctors.add(doctor);
    _saveDoctors();
    if (isFirebaseMode) {
      _firestore.saveDoctor(doctor).catchError((_) {});
    }
    notifyListeners();
  }

  void updateDoctor(Doctor doctor) {
    final i = _doctors.indexWhere((d) => d.id == doctor.id);
    if (i == -1) return;
    _doctors[i] = doctor;
    _saveDoctors();
    if (isFirebaseMode) {
      _firestore.saveDoctor(doctor).catchError((_) {});
    }
    notifyListeners();
  }

  void deleteDoctor(String id) {
    _doctors.removeWhere((d) => d.id == id);
    _saveDoctors();
    if (isFirebaseMode) {
      _firestore.deleteDoctor(id).catchError((_) {});
    }
    notifyListeners();
  }

  Future<void> updatePaymentAccount(String method, String value) async {
    paymentAccounts[method] = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('$_kAccounts:$method', value);
    if (isFirebaseMode) {
      _firestore.savePaymentAccounts(paymentAccounts).catchError((_) {});
    }
    notifyListeners();
  }

  Future<void> setGeminiApiKey(String key) async {
    _geminiKeyOverride = key.trim();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kGeminiKey, _geminiKeyOverride);
    notifyListeners();
  }

  final List<Booking> _bookings = <Booking>[
    // One pre-seeded Assistant inbox item, so the Assistant flow
    // is testable the first time the app opens.
    Booking(
      id: 'demo-1',
      doctor: sampleDoctors[2],
      patientName: 'Ahmed (Demo)',
      patientAge: 32,
      symptoms: 'Pait me 3 din se dard hai, bukhar bhi hai.',
      aiSummary: 'Pait me 3 din se dard aur bukhar.',
      suggestedSpecialty: 'Gastroenterologist',
      status: BookingStatus.paymentSent,
      offeredTime: 'Today, 5:30 PM',
      tokenNumber: 13,
      paymentMethod: 'JazzCash',
      transactionId: 'TXN-881234567',
      detectedAmount: 'Rs. 2000',
    ),
  ];

  List<Booking> get bookings => List<Booking>.unmodifiable(_bookings);

  List<Booking> get myBookings => _bookings;

  List<Booking> get assistantInbox => _bookings
      .where((b) => b.status != BookingStatus.confirmed)
      .toList();

  List<Booking> get confirmedBookings => _bookings
      .where((b) => b.status == BookingStatus.confirmed)
      .toList();

  List<Doctor> doctorsForSpecialty(String specialty) {
    final matches =
        doctors.where((d) => d.specialty == specialty).toList();
    return matches.isEmpty ? doctors : matches;
  }

  int _nextToken = 14;

  Booking createBooking({
    required Doctor doctor,
    required String patientName,
    required int patientAge,
    required String symptoms,
    required String aiSummary,
    required String suggestedSpecialty,
  }) {
    final booking = Booking(
      id: 'b${DateTime.now().millisecondsSinceEpoch}',
      doctor: doctor,
      patientName: patientName,
      patientAge: patientAge,
      symptoms: symptoms,
      aiSummary: aiSummary,
      suggestedSpecialty: suggestedSpecialty,
    );
    _bookings.insert(0, booking);
    if (isFirebaseMode) {
      _firestore.saveBooking(booking).catchError((_) {});
    }
    notifyListeners();
    return booking;
  }

  void offerTime(Booking booking, String time) {
    _update(booking, status: BookingStatus.timeOffered, offeredTime: time);
  }

  void rejectBooking(Booking booking, {String reason = 'Not available'}) {
    _update(booking,
        status: BookingStatus.rejected, rejectionReason: reason);
  }

  void submitPayment(
    Booking booking, {
    required String method,
    String? transactionId,
    String? detectedAmount,
    String? screenshotPath,
  }) {
    _update(
      booking,
      status: BookingStatus.paymentSent,
      paymentMethod: method,
      transactionId: transactionId,
      detectedAmount: detectedAmount,
      screenshotPath: screenshotPath,
    );
  }

  void approvePayment(Booking booking) {
    _update(
      booking,
      status: BookingStatus.confirmed,
      tokenNumber: _nextToken++,
    );
  }

  void _update(
    Booking booking, {
    BookingStatus? status,
    String? offeredTime,
    int? tokenNumber,
    String? paymentMethod,
    String? transactionId,
    String? detectedAmount,
    String? screenshotPath,
    String? rejectionReason,
  }) {
    final index = _bookings.indexWhere((b) => b.id == booking.id);
    if (index == -1) return;
    _bookings[index] = booking.copyWith(
      status: status,
      offeredTime: offeredTime,
      tokenNumber: tokenNumber,
      paymentMethod: paymentMethod,
      transactionId: transactionId,
      detectedAmount: detectedAmount,
      screenshotPath: screenshotPath,
      rejectionReason: rejectionReason,
    );
    if (isFirebaseMode) {
      _firestore.saveBooking(_bookings[index]).catchError((_) {});
    }
    notifyListeners();
  }
}
