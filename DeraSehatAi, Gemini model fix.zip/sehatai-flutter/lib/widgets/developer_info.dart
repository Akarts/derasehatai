import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

/// Developer info, shown in a dialog when anyone taps the
/// "Developed by" credit on the role screen.
/// Tapping the phone number opens a WhatsApp chat, tapping the
/// email opens a new mail compose.
class DeveloperInfo {
  static const String name = 'Muhammad Arsalan Kakar';
  static const String phoneDisplay = '+92343-0990125';
  static const String city = 'Dera Ismail Khan';
  static const String email = 'mohammadarsalan93@gmail.com';

  /// WhatsApp number in international format, no + or leading 0.
  static const String whatsappNumber = '923430990125';

  static Future<void> openWhatsApp() async {
    final uri = Uri.parse('https://wa.me/$whatsappNumber');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  static Future<void> openEmail() async {
    final uri = Uri(
      scheme: 'mailto',
      path: email,
      query: 'subject=DeraSehatAi',
    );
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  static Future<void> showInfoDialog(BuildContext context) async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        contentPadding: EdgeInsets.zero,
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Logo on its own dark-blue background, so the
              // transparent corners never show white or black.
              Container(
                color: const Color(0xFF072A45),
                child: Image.asset(
                  'assets/images/dera_sehat_ai_logo.png',
                  fit: BoxFit.cover,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Developed By',
                      style: TextStyle(color: Colors.grey),
                    ),
                    Text(
                      name,
                      style: const TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(
                        Icons.chat,
                        color: Color(0xFF25D366),
                      ),
                      title: const Text(phoneDisplay),
                      subtitle: const Text('Tap to chat on WhatsApp'),
                      onTap: openWhatsApp,
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(
                        Icons.email,
                        color: Color(0xFF0F766E),
                      ),
                      title: const Text(email),
                      subtitle: const Text('Tap to send an email'),
                      onTap: openEmail,
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(
                        Icons.location_on,
                        color: Color(0xFF0F766E),
                      ),
                      title: Text(city),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}

/// The app logo, shown exactly as supplied: the image itself on a
/// dark-blue container matching its own glow, so its transparent
/// corners never show a white or black background.
class DeraLogo extends StatelessWidget {
  const DeraLogo({super.key, this.height = 170});

  final double height;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        color: const Color(0xFF072A45),
        child: Image.asset(
          'assets/images/dera_sehat_ai_logo.png',
          height: height,
          width: double.infinity,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
