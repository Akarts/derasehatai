import 'package:flutter/material.dart';

import '../models/doctor.dart';

/// Doctor card used on the Patient doctor list.
class DoctorCard extends StatelessWidget {
  const DoctorCard({
    super.key,
    required this.doctor,
    required this.onTap,
    this.highlightSpecialty = false,
  });

  final Doctor doctor;
  final VoidCallback onTap;
  final bool highlightSpecialty;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: const Color(0xFF0F766E),
                child: Text(
                  doctor.name.replaceFirst('Dr. ', '').substring(0, 1),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      doctor.name,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      doctor.specialty,
                      style: TextStyle(
                        color: highlightSpecialty
                            ? const Color(0xFF0F766E)
                            : Colors.grey.shade700,
                        fontWeight: highlightSpecialty
                            ? FontWeight.bold
                            : FontWeight.normal,
                      ),
                    ),
                    Text(
                      doctor.clinic,
                      style: TextStyle(color: Colors.grey.shade600),
                    ),
                    if (doctor.location.isNotEmpty)
                      Row(
                        children: [
                          const Icon(
                            Icons.location_on,
                            size: 14,
                            color: Colors.grey,
                          ),
                          const SizedBox(width: 2),
                          Expanded(
                            child: Text(
                              doctor.location,
                              style: TextStyle(color: Colors.grey.shade600),
                            ),
                          ),
                        ],
                      ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.star,
                            size: 16, color: Colors.amber),
                        Text(' ${doctor.rating}  •  '
                            '${doctor.experienceYears} yrs exp'),
                        const Spacer(),
                        Text(
                          doctor.feeLabel,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF0F766E),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}

/// Small coloured status chip for a booking.
class StatusChip extends StatelessWidget {
  const StatusChip({super.key, required this.label, required this.isGood});

  final String label;
  final bool isGood;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: isGood ? const Color(0xFFD1FAE5) : const Color(0xFFFEF3C7),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: isGood
              ? const Color(0xFF065F46)
              : const Color(0xFF92400E),
          fontWeight: FontWeight.w600,
          fontSize: 12,
        ),
      ),
    );
  }
}

/// The AI disclaimer shown on every AI screen — the AI does not diagnose.
class AiDisclaimer extends StatelessWidget {
  const AiDisclaimer({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7ED),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFDBA74)),
      ),
      child: const Row(
        children: [
          Icon(Icons.info_outline, color: Color(0xFF9A3412)),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'AI diagnosis nahi deta — sirf sahi doctor tak pahunchata hai. '
              'Emergency me foran hospital jayein.',
              style: TextStyle(fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}
