import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/doctor.dart';
import '../../providers/booking_provider.dart';
import '../../widgets/doctor_card.dart';
import 'booking_screen.dart';

/// Screen 3 (Patient): doctors for the AI-suggested specialty first,
/// then the rest. Tapping a doctor opens the booking request.
class DoctorListScreen extends StatelessWidget {
  const DoctorListScreen({
    super.key,
    required this.suggestedSpecialty,
    required this.symptoms,
    required this.aiSummary,
  });

  final String suggestedSpecialty;
  final String symptoms;
  final String aiSummary;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<BookingProvider>();
    final suggested = provider.doctorsForSpecialty(suggestedSpecialty);
    final others = provider.doctors
        .where((d) => !suggested.contains(d))
        .toList();

    return Scaffold(
      appBar: AppBar(title: Text(suggestedSpecialty)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'AI ne ye suggest kiya: $suggestedSpecialty',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          ...suggested.map(
            (d) => DoctorCard(
              doctor: d,
              highlightSpecialty: true,
              onTap: () => _openBooking(context, d),
            ),
          ),
          if (others.isNotEmpty) ...[
            const SizedBox(height: 8),
            const Text(
              'Doosre doctors',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
            ),
            const SizedBox(height: 8),
            ...others.map(
              (d) => DoctorCard(
                doctor: d,
                onTap: () => _openBooking(context, d),
              ),
            ),
          ],
        ],
      ),
    );
  }

  void _openBooking(BuildContext context, Doctor doctor) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BookingScreen(
          doctor: doctor,
          symptoms: symptoms,
          aiSummary: aiSummary,
          suggestedSpecialty: suggestedSpecialty,
        ),
      ),
    );
  }
}
