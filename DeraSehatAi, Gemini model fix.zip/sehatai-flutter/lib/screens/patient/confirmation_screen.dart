import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/booking.dart';
import '../../providers/booking_provider.dart';

/// Screen 6 (Patient): booking confirmed, with Token #.
/// In the demo the Assistant approval is simulated by the Assistant screens;
/// this screen refreshes live from BookingProvider.
class ConfirmationScreen extends StatelessWidget {
  const ConfirmationScreen({super.key, required this.booking});

  final Booking booking;

  @override
  Widget build(BuildContext context) {
    final live = context.watch<BookingProvider>().bookings.firstWhere(
          (b) => b.id == booking.id,
          orElse: () => booking,
        );
    final confirmed = live.status == BookingStatus.confirmed;
    return Scaffold(
      appBar: AppBar(title: const Text('Booking status')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Icon(
              confirmed ? Icons.check_circle : Icons.hourglass_top,
              size: 88,
              color: confirmed
                  ? const Color(0xFF059669)
                  : const Color(0xFFD97706),
            ),
            const SizedBox(height: 16),
            Text(
              confirmed ? 'Booking Confirmed!' : 'Payment Assistant ko bhej di gayi',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              confirmed
                  ? 'Assistant ne payment verify kar li hai.'
                  : 'Assistant screenshot aur Transaction ID verify kar raha hai. '
                      'Approve hote hi Token mil jayega.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.grey, fontSize: 16),
            ),
            const SizedBox(height: 24),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  children: [
                    Text(live.doctor.name,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    Text(live.doctor.clinic),
                    const Divider(height: 24),
                    _row('Time', live.offeredTime ?? '—'),
                    _row('Fee', live.doctor.feeLabel),
                    _row('Payment', live.paymentMethod ?? '—'),
                    _row('Transaction ID', live.transactionId ?? '—'),
                    _row('Status', live.status.label),
                    if (confirmed) ...[
                      const Divider(height: 24),
                      const Text('TOKEN NUMBER',
                          style: TextStyle(color: Colors.grey)),
                      Text(
                        '#${live.tokenNumber ?? '—'}',
                        style: const TextStyle(
                          fontSize: 44,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF0F766E),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () => Navigator.popUntil(
                context,
                (route) => route.isFirst,
              ),
              child: const Text('Home par wapas jayein'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey)),
          Flexible(
            child: Text(value,
                textAlign: TextAlign.right,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}
