import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:speech_to_text/speech_to_text.dart';

import '../../models/triage_result.dart';
import '../../providers/booking_provider.dart';
import '../../services/gemini_service.dart';
import '../../widgets/doctor_card.dart';
import 'doctor_list_screen.dart';

/// Screen 2 (Patient): tell the AI your problem by typing or voice,
/// in Urdu / Roman Urdu / English. Gemini replies with a summary,
/// a suggested specialist and follow-up questions.
class SymptomScreen extends StatefulWidget {
  const SymptomScreen({super.key, required this.language});

  final String language;

  @override
  State<SymptomScreen> createState() => _SymptomScreenState();
}

class _SymptomScreenState extends State<SymptomScreen> {
  final TextEditingController _controller = TextEditingController();
  final SpeechToText _speech = SpeechToText();

  TriageResult? _result;
  bool _loading = false;
  bool _listening = false;

  Future<void> _toggleListening() async {
    if (_listening) {
      await _speech.stop();
      setState(() => _listening = false);
      return;
    }
    // Microphone permission is required — without it, speech
    // recognition never starts (this was the voice bug).
    var mic = await Permission.microphone.status;
    if (!mic.isGranted) {
      mic = await Permission.microphone.request();
    }
    if (!mic.isGranted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              mic.isPermanentlyDenied
                  ? 'Microphone permission off hai — Settings > Apps > '
                      'DeraSehatAi > Permissions se Microphone on karein.'
                  : 'Voice ke liye microphone permission chahiye.',
            ),
          ),
        );
      }
      return;
    }
    final available = await _speech.initialize(
      onError: (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Voice error: ${e.errorMsg}')),
          );
        }
      },
      onStatus: (status) {
        if (status == 'done' || status == 'notListening') {
          if (mounted) setState(() => _listening = false);
        }
      },
    );
    if (!available) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Voice input is device par nahi mila.')),
        );
      }
      return;
    }
    // Use the device's matching locale when available, otherwise
    // fall back to English — a missing ur-PK locale used to fail
    // silently.
    String localeId = widget.language == 'Urdu' ? 'ur-PK' : 'en-US';
    try {
      final locales = await _speech.locales();
      final wanted = widget.language == 'Urdu' ? 'ur' : 'en';
      final match = locales
          .where((l) => l.localeId.toLowerCase().startsWith(wanted))
          .toList();
      if (match.isNotEmpty) localeId = match.first.localeId;
    } catch (_) {
      // Keep the default localeId above.
    }
    setState(() => _listening = true);
    await _speech.listen(
      onResult: (r) => setState(() => _controller.text = r.recognizedWords),
      localeId: localeId,
      listenFor: const Duration(seconds: 60),
      pauseFor: const Duration(seconds: 5),
      partialResults: true,
    );
  }

  Future<void> _analyse() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _loading = true;
      _result = null;
    });
    // Use the key from the Admin panel (or lib/config.dart) — the
    // key saved in the Admin panel lives in BookingProvider, so a
    // GeminiService built without it would always fall back to
    // the demo mock. That was the "always General Physician" bug.
    final provider = context.read<BookingProvider>();
    final gemini = GeminiService(apiKey: provider.effectiveGeminiApiKey);
    final result = await gemini.triage(text);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _result = result;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _speech.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Apni takleef batayein')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Zuban: ${widget.language}  •  AI: ${context.watch<BookingProvider>().isGeminiConfigured ? 'Gemini (live)' : 'Demo mode'}',
              style: const TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _controller,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText:
                    'Jaise: "Pait me 3 din se dard hai, bukhar bhi hai."',
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _toggleListening,
                    icon: Icon(_listening ? Icons.mic_off : Icons.mic),
                    label: Text(_listening ? 'Sun raha hai…' : 'Bol kar batayein'),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                      foregroundColor: const Color(0xFF0F766E),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _loading ? null : _analyse,
                    child: _loading
                        ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text('AI se puchein'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (_result != null) _buildResult(_result!),
            const SizedBox(height: 16),
            const AiDisclaimer(),
          ],
        ),
      ),
    );
  }

  Widget _buildResult(TriageResult result) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (result.isDemo)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFBEB),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.amber.shade300),
                ),
                child: const Text(
                  'Ye demo jawab hai — AI live nahi hai. '
                  'Admin se Gemini key check karwayein.',
                  style: TextStyle(
                    color: Color(0xFF92400E),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            if (result.isEmergency)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFEF2F2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.red.shade300),
                ),
                child: const Text(
                  '⚠️ Emergency alamat lagti hai — foran hospital / 1122 se rabta karein.',
                  style: TextStyle(
                    color: Color(0xFF991B1B),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            const Text('AI Summary',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 4),
            Text(result.summary, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('Suggested: ',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                Expanded(
                  child: Text(
                    result.suggestedSpecialty,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0F766E),
                    ),
                  ),
                ),
                Text('${result.confidencePercent}% match'),
              ],
            ),
            const SizedBox(height: 10),
            const Text('AI ke sawal:',
                style: TextStyle(fontWeight: FontWeight.w600)),
            ...result.followUpQuestions
                .map((q) => Text('• $q'))
                .toList(),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => DoctorListScreen(
                    suggestedSpecialty: result.suggestedSpecialty,
                    symptoms: _controller.text.trim(),
                    aiSummary: result.summary,
                  ),
                ),
              ),
              child: Text('${result.suggestedSpecialty} dekhein'),
            ),
          ],
        ),
      ),
    );
  }
}
