import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../models/booking.dart';
import '../../providers/booking_provider.dart';
import '../../services/gemini_service.dart';
import 'confirmation_screen.dart';

/// Screen 5 (Patient): manual local payment.
/// JazzCash / Easypaisa / Bank Transfer — patient pays, then uploads
/// the payment screenshot. AI reads the screenshot and auto-detects
/// the Transaction ID and amount — the patient never types it.
/// The Assistant then verifies the AI-detected ID.
class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key, required this.booking});

  final Booking booking;

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String _method = 'JazzCash';
  XFile? _screenshot;
  bool _detecting = false;
  String? _detectedId;
  String? _detectedAmount;
  String? _detectError;

  static const _methods = <String>[
    'JazzCash',
    'Easypaisa',
    'Bank Transfer',
  ];

  Future<void> _pickScreenshot() async {
    final file = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (file == null) return;
    setState(() {
      _screenshot = file;
      _detectedId = null;
      _detectedAmount = null;
      _detectError = null;
      _detecting = true;
    });
    try {
      final provider = context.read<BookingProvider>();
      final bytes = await file.readAsBytes();
      final service = GeminiService(apiKey: provider.effectiveGeminiApiKey);
      if (!service.isConfigured) {
        setState(() {
          _detecting = false;
          _detectError =
              'AI detection ke liye Gemini API key chahiye. '
              'Admin panel me key add karein, phir dobara try karein.';
        });
        return;
      }
      final details = await service.extractTransactionDetails(bytes);
      setState(() {
        _detecting = false;
        if (details != null) {
          _detectedId = details.transactionId;
          _detectedAmount =
              details.amount.isNotEmpty ? details.amount : null;
        } else {
          _detectError =
              'Transaction ID detect nahi hua — saaf screenshot '
              'dobara upload karein.';
        }
      });
    } catch (_) {
      setState(() {
        _detecting = false;
        _detectError =
            'AI detection fail ho gaya — dobara try karein.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final booking = widget.booking;
    final provider = context.watch<BookingProvider>();
    final accounts = provider.paymentAccounts;
    return Scaffold(
      appBar: AppBar(title: const Text('Payment karein')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(booking.doctor.name,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('Time: ${booking.offeredTime ?? '—'}'),
                    Text(
                      'Fee: ${booking.doctor.feeLabel}',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF0F766E),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text('Payment method',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ..._methods.map(
              (m) => RadioListTile<String>(
                value: m,
                groupValue: _method,
                title: Text(m),
                onChanged: (v) => setState(() => _method = v!),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(accounts[_method] ?? ''),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: _detecting ? null : _pickScreenshot,
              icon: const Icon(Icons.upload),
              label: Text(
                _screenshot == null
                    ? 'Payment screenshot upload karein'
                    : 'Screenshot selected ✓ — dobara select karein',
              ),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
                foregroundColor: const Color(0xFF0F766E),
              ),
            ),
            if (_screenshot != null) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(_screenshot!.path),
                  height: 180,
                  fit: BoxFit.cover,
                ),
              ),
            ],
            const SizedBox(height: 12),
            if (_detecting)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(14),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'AI screenshot parh raha hai — '
                          'Transaction ID detect ho raha hai…',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            if (_detectedId != null)
              Card(
                color: const Color(0xFFD1FAE5),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '✓ AI ne detect kiya',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Transaction ID: $_detectedId',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      if (_detectedAmount != null)
                        Text('Amount: $_detectedAmount'),
                      const SizedBox(height: 4),
                      const Text(
                        'Aap ko Transaction ID type karne ki zaroorat '
                        'nahi — Assistant yehi ID verify karega.',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ),
            if (_detectError != null)
              Card(
                color: const Color(0xFFFEF3C7),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text(_detectError!),
                ),
              ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _detecting
                  ? null
                  : () {
                      if (_screenshot == null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'Pehle payment screenshot upload karein.',
                            ),
                          ),
                        );
                        return;
                      }
                      context.read<BookingProvider>().submitPayment(
                            booking,
                            method: _method,
                            transactionId: _detectedId,
                            detectedAmount: _detectedAmount,
                            screenshotPath: _screenshot?.path,
                          );
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              ConfirmationScreen(booking: booking),
                        ),
                      );
                    },
              child: const Text('Payment bhej di — Assistant verify karega'),
            ),
            const SizedBox(height: 10),
            const Text(
              'Assistant screenshot aur AI-detected Transaction ID '
              'check karke Approve karega, tab booking confirm hogi.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
