import 'package:flutter/material.dart';

import '../../widgets/developer_info.dart';
import 'symptom_screen.dart';

/// Screen 1 (Patient): welcome + language selection.
/// The choice is stored in the Symptom screen and passed to Gemini
/// so the AI can reply in the patient's language.
class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  String _language = 'Roman Urdu';

  static const _languages = <String>[
    'Urdu',
    'Roman Urdu',
    'English',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('DeraSehatAi')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const DeraLogo(height: 150),
            const SizedBox(height: 20),
            const Text(
              'Assalam-o-Alaikum!',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Apni takleef batayein — AI aap ko sahi doctor tak pahunchayega.',
              style: TextStyle(fontSize: 17, color: Colors.grey),
            ),
            const SizedBox(height: 32),
            const Text(
              'Apni zuban select karein',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            ..._languages.map(
              (lang) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ChoiceChip(
                  label: SizedBox(
                    width: double.infinity,
                    child: Text(lang, textAlign: TextAlign.center),
                  ),
                  selected: _language == lang,
                  onSelected: (_) => setState(() => _language = lang),
                  selectedColor: const Color(0xFFCCFBF1),
                  labelStyle: const TextStyle(fontSize: 17),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SymptomScreen(language: _language),
                ),
              ),
              child: const Text('Shuru karein  →'),
            ),
          ],
        ),
      ),
    );
  }
}
