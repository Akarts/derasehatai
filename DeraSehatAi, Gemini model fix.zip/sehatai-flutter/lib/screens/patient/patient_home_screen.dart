import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/booking.dart';
import '../../providers/booking_provider.dart';
import '../../widgets/developer_info.dart';
import '../../widgets/doctor_card.dart';
import 'confirmation_screen.dart';
import 'welcome_screen.dart';

/// Patient home with bottom navigation: Home / My Bookings.
/// "AI se puchein" starts the Welcome → Symptom → Doctor flow.
class PatientHomeScreen extends StatefulWidget {
  const PatientHomeScreen({super.key});

  @override
  State<PatientHomeScreen> createState() => _PatientHomeScreenState();
}

class _PatientHomeScreenState extends State<PatientHomeScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final bookings = context.watch<BookingProvider>().myBookings;
    return Scaffold(
      appBar: AppBar(
        title: const Text('DeraSehatAi'),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            tooltip: 'Developer info',
            onPressed: () => DeveloperInfo.showInfoDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.swap_horiz),
            tooltip: 'Role change karein',
            onPressed: () => Navigator.pushNamedAndRemoveUntil(
              context,
              '/',
              (_) => false,
            ),
          ),
        ],
      ),
      body: _tab == 0 ? _homeTab(context) : _bookingsTab(bookings),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        selectedItemColor: const Color(0xFF0F766E),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month),
            label: 'My Bookings',
          ),
        ],
      ),
    );
  }

  Widget _homeTab(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Aaj aap kaisa mehsoos kar rahe hain?',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Apni takleef batayein, AI sahi doctor suggest karega.',
            style: TextStyle(color: Colors.grey, fontSize: 16),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const WelcomeScreen()),
            ),
            icon: const Icon(Icons.psychology),
            label: const Text('AI se puchein — takleef batayein'),
          ),
          const SizedBox(height: 16),
          const AiDisclaimer(),
        ],
      ),
    );
  }

  Widget _bookingsTab(List<Booking> bookings) {
    if (bookings.isEmpty) {
      return const Center(child: Text('Abhi koi booking nahi hai.'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: bookings.length,
      itemBuilder: (context, i) {
        final b = bookings[i];
        return Card(
          child: ListTile(
            title: Text(b.doctor.name),
            subtitle: Text(
              '${b.doctor.specialty} • ${b.offeredTime ?? 'Time pending'}',
            ),
            trailing: StatusChip(
              label: b.status.label,
              isGood: b.status == BookingStatus.confirmed,
            ),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ConfirmationScreen(booking: b),
              ),
            ),
          ),
        );
      },
    );
  }
}
