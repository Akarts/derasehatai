import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/doctor.dart';
import '../../providers/booking_provider.dart';
import 'payment_screen.dart';

/// Screen 4 (Patient): confirm the doctor and send a booking request
/// to the doctor's Assistant. The Assistant picks the time — the patient does not.
/// After the Assistant offers a time, the patient is asked to pay.
class BookingScreen extends StatefulWidget {
  const BookingScreen({
    super.key,
    required this.doctor,
    required this.symptoms,
    required this.aiSummary,
    required this.suggestedSpecialty,
  });

  final Doctor doctor;
  final String symptoms;
  final String aiSummary;
  final String suggestedSpecialty;

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final _nameController = TextEditingController(text: 'Ahmed');
  final _ageController = TextEditingController(text: '32');
  bool _sent = false;

  @override
  void dispose() {
    _nameController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final doctor = widget.doctor;
    return Scaffold(
      appBar: AppBar(title: const Text('Booking request')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(doctor.name,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold)),
                    Text(doctor.specialty,
                        style: const TextStyle(
                            color: Color(0xFF0F766E), fontSize: 16)),
                    Text(doctor.clinic),
                    const SizedBox(height: 8),
                    Text('Fee: ${doctor.feeLabel}   •   ⭐ ${doctor.rating}'),
                    Text('Assistant: ${doctor.assistantName}'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text('AI Summary',
                style: TextStyle(fontWeight: FontWeight.bold)),
            Text(widget.aiSummary),
            const SizedBox(height: 16),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Patient ka naam'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _ageController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Umar (age)'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _sent
                  ? null
                  : () {
                      final provider = context.read<BookingProvider>();
                      final booking = provider.createBooking(
                        doctor: doctor,
                        patientName: _nameController.text.trim().isEmpty
                            ? 'Patient'
                            : _nameController.text.trim(),
                        patientAge:
                            int.tryParse(_ageController.text) ?? 0,
                        symptoms: widget.symptoms,
                        aiSummary: widget.aiSummary,
                        suggestedSpecialty: widget.suggestedSpecialty,
                      );
                      setState(() => _sent = true);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Request ${doctor.assistantName} ko bhej di gayi.',
                          ),
                        ),
                      );
                      // Demo shortcut: the Assistant offers a time right away
                      // so the payment screen can be tested. In the real
                      // app this happens on the Assistant's phone.
                      provider.offerTime(booking, 'Today, 5:30 PM');
                      // Re-read the booking: offerTime replaces it in the
                      // provider, so the old object has no offeredTime.
                      final updated = provider.bookings.firstWhere(
                        (b) => b.id == booking.id,
                        orElse: () => booking,
                      );
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PaymentScreen(booking: updated),
                        ),
                      );
                    },
              child: const Text('Request Assistant ko bhejein'),
            ),
            const SizedBox(height: 12),
            const Text(
              'Assistant time select karega, phir aap ko payment ka message aayega. '
              'Payment ke baghair booking confirm nahi hogi.',
              style: TextStyle(color: Colors.grey),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
