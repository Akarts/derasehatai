import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../widgets/developer_info.dart';
import 'admin/admin_login_screen.dart';
import 'assistant/assistant_home_screen.dart';
import 'patient/patient_home_screen.dart';

/// First screen: one app, three roles. The patient, the doctor's
/// Assistant and the developer (Admin) use the same app — role
/// selection decides which home opens.
/// (Production: replace this with phone-OTP login via Firebase Auth
/// and store the role in Firestore.)
class RoleScreen extends StatefulWidget {
  const RoleScreen({super.key});

  @override
  State<RoleScreen> createState() => _RoleScreenState();
}

class _RoleScreenState extends State<RoleScreen> {
  @override
  void initState() {
    super.initState();
    _askMicrophoneOnce();
  }

  /// Ask for the microphone the first time the app opens, so voice
  /// input works when the patient reaches the symptom screen.
  /// Asked only once — if the user denies it, the symptom screen
  /// asks again and explains how to turn it on in Settings.
  Future<void> _askMicrophoneOnce() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('dera_mic_asked') == true) return;
      await prefs.setBool('dera_mic_asked', true);
      if (await Permission.microphone.isGranted) return;
      await Permission.microphone.request();
    } catch (_) {
      // Permission request must never block the app from opening.
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const DeraLogo(height: 160),
              const SizedBox(height: 16),
              const Text(
                'AI se sahi doctor, asaan booking',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 48),
              ElevatedButton.icon(
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const PatientHomeScreen(),
                  ),
                ),
                icon: const Icon(Icons.person),
                label: const Text('Main Patient hoon'),
              ),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const AssistantHomeScreen()),
                ),
                icon: const Icon(Icons.medical_services_outlined),
                label: const Text("Main Doctor ka Assistant hoon"),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  side: const BorderSide(color: Color(0xFF0F766E)),
                  foregroundColor: const Color(0xFF0F766E),
                ),
              ),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AdminLoginScreen(),
                  ),
                ),
                icon: const Icon(Icons.admin_panel_settings_outlined),
                label: const Text('Main Admin / Developer hoon'),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  side: const BorderSide(color: Color(0xFF0F766E)),
                  foregroundColor: const Color(0xFF0F766E),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Demo: koi login / password nahi — role select karein '
                'aur flow test karein.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 13),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () => DeveloperInfo.showInfoDialog(context),
                child: const Text(
                  'Developed By: Muhammad Arsalan Kakar',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey, fontSize: 13),
                ),
              ),
            ],
          ),
        ),
        ),
      ),
    );
  }
}
