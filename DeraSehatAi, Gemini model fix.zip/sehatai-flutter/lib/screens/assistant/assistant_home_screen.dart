import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/booking.dart';
import '../../providers/booking_provider.dart';
import '../../widgets/doctor_card.dart';
import 'assistant_payment_verify_screen.dart';

/// Assistant home: inbox of incoming booking requests with the AI summary.
/// The Assistant picks an available time slot, or rejects the request.
/// A second tab lists confirmed bookings.
class AssistantHomeScreen extends StatefulWidget {
  const AssistantHomeScreen({super.key});

  @override
  State<AssistantHomeScreen> createState() => _AssistantHomeScreenState();
}

class _AssistantHomeScreenState extends State<AssistantHomeScreen> {
  int _tab = 0;

  static const _slots = <String>[
    'Today, 4:00 PM',
    'Today, 5:30 PM',
    'Today, 7:00 PM',
    'Tomorrow, 10:00 AM',
    'Tomorrow, 12:00 PM',
  ];

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<BookingProvider>();
    final inbox = provider.assistantInbox;
    final confirmed = provider.confirmedBookings;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Assistant Dashboard — Dr. Usman Ali'),
        actions: [
          IconButton(
            icon: const Icon(Icons.swap_horiz),
            tooltip: 'Role change karein',
            onPressed: () => Navigator.pushNamedAndRemoveUntil(
              context,
              '/',
              (_) => false,
            ),
          ),
        ],
      ),
      body: _tab == 0 ? _inboxTab(provider, inbox) : _confirmedTab(confirmed),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        selectedItemColor: const Color(0xFF0F766E),
        items: [
          BottomNavigationBarItem(
            icon: const Icon(Icons.inbox),
            label: 'Inbox (${inbox.length})',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.check_circle),
            label: 'Confirmed',
          ),
        ],
      ),
    );
  }

  Widget _inboxTab(BookingProvider provider, List<Booking> inbox) {
    if (inbox.isEmpty) {
      return const Center(child: Text('Koi nayi request nahi hai.'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: inbox.length,
      itemBuilder: (context, i) {
        final b = inbox[i];
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${b.patientName}, ${b.patientAge} yrs',
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    StatusChip(label: b.status.label, isGood: false),
                  ],
                ),
                Text('${b.doctor.name} • ${b.doctor.specialty}'),
                const SizedBox(height: 8),
                const Text('AI Summary',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                Text(b.aiSummary),
                Text('Suggested: ${b.suggestedSpecialty}'),
                if (b.offeredTime != null)
                  Text('Offered time: ${b.offeredTime}'),
                if (b.transactionId != null)
                  Text('AI-detected Txn ID: ${b.transactionId}'),
                const SizedBox(height: 12),
                if (b.status == BookingStatus.requested) ...[
                  const Text('Time select karein:',
                      style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _slots
                        .map(
                          (slot) => ChoiceChip(
                            label: Text(slot),
                            selected: false,
                            onSelected: (_) {
                              provider.offerTime(b, slot);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'Time offer kar diya: $slot. '
                                    'Patient ko payment ka message jayega.',
                                  ),
                                ),
                              );
                            },
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () => provider.rejectBooking(
                      b,
                      reason: 'Doctor available nahi hai',
                    ),
                    child: const Text(
                      'Reject karein',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                ],
                if (b.status == BookingStatus.paymentSent)
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AssistantPaymentVerifyScreen(booking: b),
                        ),
                      ),
                      child: const Text('Payment verify karein'),
                    ),
                  ),
                if (b.status == BookingStatus.timeOffered)
                  const Text(
                    'Patient se payment ka intezar hai…',
                    style: TextStyle(color: Colors.grey),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _confirmedTab(List<Booking> confirmed) {
    if (confirmed.isEmpty) {
      return const Center(child: Text('Abhi koi confirmed booking nahi.'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: confirmed.length,
      itemBuilder: (context, i) {
        final b = confirmed[i];
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: const Color(0xFF059669),
              child: Text(
                '#${b.tokenNumber ?? '—'}',
                style: const TextStyle(color: Colors.white, fontSize: 12),
              ),
            ),
            title: Text(b.patientName),
            subtitle: Text(
              '${b.doctor.name} • ${b.offeredTime ?? ''} • ${b.paymentMethod ?? ''}',
            ),
            trailing: const StatusChip(label: 'Confirmed', isGood: true),
          ),
        );
      },
    );
  }
}
