import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/booking.dart';
import '../../providers/booking_provider.dart';

/// Assistant payment verification: shows the patient's uploaded screenshot
/// (or a placeholder in the demo) and Transaction ID, with
/// Approve / Reject buttons. Approving issues a Token #.
class AssistantPaymentVerifyScreen extends StatelessWidget {
  const AssistantPaymentVerifyScreen({super.key, required this.booking});

  final Booking booking;

  @override
  Widget build(BuildContext context) {
    final provider = context.read<BookingProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Payment verify karein')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(booking.patientName,
                        style: const TextStyle(
                            fontSize: 19, fontWeight: FontWeight.bold)),
                    Text('${booking.doctor.name} • ${booking.doctor.feeLabel}'),
                    Text('Time: ${booking.offeredTime ?? '—'}'),
                    Text('Method: ${booking.paymentMethod ?? '—'}'),
                    Text(
                      'Transaction ID (AI-detected): ${booking.transactionId ?? '—'}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    if (booking.detectedAmount != null)
                      Text('Amount (AI-detected): ${booking.detectedAmount}'),
                    const Text(
                      'AI ne ye ID payment screenshot se parha hai — '
                      'patient ne type nahi kiya.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text('Payment screenshot',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            if (booking.screenshotPath != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(booking.screenshotPath!),
                  height: 220,
                  fit: BoxFit.cover,
                ),
              )
            else
              Container(
                height: 220,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.receipt_long, size: 48, color: Colors.grey),
                      SizedBox(height: 8),
                      Text(
                        'Screenshot placeholder\n'
                        '(demo booking — koi file upload nahi hui)',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 8),
            const Text(
              'Screenshot me AI-detected Transaction ID check karein, '
              'phir Approve karein. Galat ho to Reject karein.',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                provider.approvePayment(booking);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Booking confirmed! Token issue ho gaya.')),
                );
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF059669),
              ),
              child: const Text('✓ Approve — Booking Confirm karein'),
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () {
                provider.rejectBooking(
                  booking,
                  reason: 'Payment verify nahi hui',
                );
                Navigator.pop(context);
              },
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
                foregroundColor: Colors.red,
                side: const BorderSide(color: Colors.red),
              ),
              child: const Text('✕ Reject — Payment galat hai'),
            ),
          ],
        ),
      ),
    );
  }
}
