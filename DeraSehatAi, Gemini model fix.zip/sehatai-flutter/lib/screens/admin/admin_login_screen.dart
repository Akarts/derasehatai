import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../services/firestore_service.dart';
import 'admin_home_screen.dart';

/// The single admin account.
///
/// OFFLINE (no Firebase yet): the account is created on this phone
/// only, password stored as a SHA-256 hash in SharedPreferences.
///
/// FIREBASE (configured): the account is a Firebase Auth user
/// (email + password, created in the Firebase console) whose UID
/// is listed in Firestore `admins/<uid>`. Only that user can open
/// the Admin panel, on any phone. No one can create an admin from
/// inside the app.
class AdminAuth {
  static const _kUsername = 'dera_admin_username';
  static const _kPasswordHash = 'dera_admin_password_hash';

  static String _hash(String password) =>
      sha256.convert(utf8.encode(password)).toString();

  static Future<bool> adminExists() async {
    // In Firebase mode there is always an admin to log in as —
    // creation happens in the Firebase console, never in the app.
    if (FirestoreService.isConfigured) return true;
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getString(_kUsername) ?? '').isNotEmpty &&
        (prefs.getString(_kPasswordHash) ?? '').isNotEmpty;
  }

  /// Create the ONE admin account. Local mode only.
  static Future<void> createAdmin(String username, String password) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kUsername, username);
    await prefs.setString(_kPasswordHash, _hash(password));
  }

  /// Verify a username/email + password against the stored admin.
  static Future<bool> verify(String username, String password) async {
    if (FirestoreService.isConfigured) {
      // Firebase mode: username is the admin's email.
      try {
        final cred = await FirebaseAuth.instance
            .signInWithEmailAndPassword(email: username, password: password);
        final uid = cred.user?.uid;
        if (uid == null) return false;
        final isAdmin = await FirestoreService().isAdminUser(uid);
        if (!isAdmin) {
          await FirebaseAuth.instance.signOut();
          return false;
        }
        return true;
      } catch (_) {
        return false;
      }
    }
    final prefs = await SharedPreferences.getInstance();
    final storedUser = prefs.getString(_kUsername) ?? '';
    final storedHash = prefs.getString(_kPasswordHash) ?? '';
    return username.isNotEmpty &&
        username == storedUser &&
        storedHash.isNotEmpty &&
        storedHash == _hash(password);
  }

  /// Change the admin password (from inside the Admin panel).
  /// Returns false when the current password is wrong.
  static Future<bool> changePassword(
    String currentPassword,
    String newPassword,
  ) async {
    if (FirestoreService.isConfigured) {
      try {
        final user = FirebaseAuth.instance.currentUser;
        if (user == null || user.email == null) return false;
        await user.reauthenticateWithCredential(
          EmailAuthProvider.credential(
            email: user.email!,
            password: currentPassword,
          ),
        );
        await user.updatePassword(newPassword);
        return true;
      } catch (_) {
        return false;
      }
    }
    final prefs = await SharedPreferences.getInstance();
    final storedHash = prefs.getString(_kPasswordHash) ?? '';
    if (storedHash.isEmpty || storedHash != _hash(currentPassword)) {
      return false;
    }
    await prefs.setString(_kPasswordHash, _hash(newPassword));
    return true;
  }

  static Future<void> signOut() async {
    if (FirestoreService.isConfigured) {
      await FirebaseAuth.instance.signOut();
    }
  }
}

/// Admin login — only ONE admin account is allowed in the whole app.
///
/// First time: there is no admin yet, so this screen asks you to
/// CREATE the one admin account (username + password, your choice).
/// After that, this screen is a login — only those credentials open
/// the Admin panel. There is no second admin and no register link.
///
/// Production: move admin login to Firebase Auth (email + password
/// with an admin claim) so the account is not only on one phone.
class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final _userController = TextEditingController();
  final _passController = TextEditingController();
  final _confirmController = TextEditingController();

  bool _loading = true;
  bool _adminExists = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _checkAdmin();
  }

  Future<void> _checkAdmin() async {
    final exists = await AdminAuth.adminExists();
    setState(() {
      _adminExists = exists;
      _loading = false;
    });
  }

  Future<void> _submit() async {
    final username = _userController.text.trim();
    final password = _passController.text;
    if (username.isEmpty || password.isEmpty) {
      setState(() => _error = 'Username aur password dono likhein.');
      return;
    }
    if (password.length < 6) {
      setState(() => _error = 'Password kam se kam 6 characters ka ho.');
      return;
    }

    if (!_adminExists) {
      // First time only: create the ONE admin account.
      if (_confirmController.text != password) {
        setState(() => _error = 'Password aur confirm password same nahi hain.');
        return;
      }
      await AdminAuth.createAdmin(username, password);
    } else {
      // Login: username AND password must both match.
      if (!await AdminAuth.verify(username, password)) {
        setState(() => _error = 'Galat username ya password. Dobara try karein.');
        return;
      }
    }
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const AdminHomeScreen()),
    );
  }

  @override
  void dispose() {
    _userController.dispose();
    _passController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Login')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(
              Icons.admin_panel_settings,
              size: 72,
              color: Color(0xFF0F766E),
            ),
            const SizedBox(height: 16),
            Text(
              _adminExists
                  ? 'Admin panel kholne ke liye login karein.'
                  : 'Pehli dafa: apna ek Admin account banayein.\n'
                      'Sirf yehi ek admin hoga — doosra admin nahi ban sakta.',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, color: Colors.grey),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _userController,
              decoration: const InputDecoration(labelText: 'Admin username'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _passController,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Password'),
            ),
            if (!_adminExists) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _confirmController,
                obscureText: true,
                decoration:
                    const InputDecoration(labelText: 'Password dobara likhein'),
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(
                _error!,
                style: const TextStyle(color: Colors.red),
                textAlign: TextAlign.center,
              ),
            ],
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _submit,
              child: Text(_adminExists ? 'Login karein' : 'Admin Account Banayein'),
            ),
            const SizedBox(height: 12),
            const Text(
              'Password bhool gaye to app ka data clear karna parega — '
              'is liye password kahi safe likh lein.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
