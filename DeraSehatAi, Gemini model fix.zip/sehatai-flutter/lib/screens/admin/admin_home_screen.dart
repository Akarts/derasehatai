import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/doctor.dart';
import '../../providers/booking_provider.dart';
import '../../services/firestore_service.dart';
import '../../services/gemini_service.dart';
import 'admin_login_screen.dart';

/// Admin panel (developer). Add, edit and delete doctors with
/// their clinic location, edit the payment account numbers, and
/// set the Gemini API key.
///
/// Firebase mode: doctors / settings are shared in Firestore, and
/// the panel is protected by the Firebase Auth admin login.
/// Offline mode: everything is saved on this phone only.
class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({super.key});

  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {
  final _keyController = TextEditingController();
  bool _keyLoaded = false;

  @override
  void initState() {
    super.initState();
    // First time the admin opens the panel in Firebase mode, upload
    // the 6 sample doctors to Firestore — only if the collection is
    // still empty. After that, every phone sees the same list.
    if (FirestoreService.isConfigured) {
      FirestoreService().seedDoctorsIfEmpty().catchError((_) {});
    }
  }

  @override
  void dispose() {
    _keyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<BookingProvider>();
    if (!_keyLoaded) {
      _keyLoaded = true;
      _keyController.text =
          provider.isGeminiConfigured ? '•••••••• (saved)' : '';
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel — Developer'),
        actions: [
          IconButton(
            icon: const Icon(Icons.swap_horiz),
            tooltip: 'Role change karein',
            onPressed: () => Navigator.pushNamedAndRemoveUntil(
              context,
              '/',
              (_) => false,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Gemini API Key',
                      style:
                          TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      provider.isGeminiConfigured
                          ? 'AI configured hai ✓'
                          : 'AI abhi mock mode me hai — key add karein.',
                      style: const TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _keyController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Gemini API key',
                        hintText: 'AIza…',
                      ),
                    ),
                    const SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () async {
                        final key = _keyController.text.trim();
                        if (key.isEmpty || key.contains('•')) return;
                        await provider.setGeminiApiKey(key);
                        if (!mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Gemini API key save ho gayi.'),
                          ),
                        );
                      },
                      child: const Text('API Key Save karein'),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton(
                      onPressed: () async {
                        final service = GeminiService(
                          apiKey: provider.effectiveGeminiApiKey,
                        );
                        final result = await service.triage(
                          'mere daant mein dard hai',
                        );
                        if (!mounted) return;
                        final error = GeminiService.lastError;
                        showDialog<void>(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            title: Text(
                              result.isDemo ? 'AI Test — FAILED' : 'AI Test — OK',
                            ),
                            content: Text(
                              result.isDemo
                                  ? 'Gemini ne jawab nahi diya, demo jawab mila.\n\n'
                                      'Error: ${error ?? 'unknown'}\n\n'
                                      'Key galat ho, model band ho, ya internet '
                                      'ka masla ho sakta hai.'
                                  : 'Gemini live hai.\n\n'
                                      'Test: daant dard → ${result.suggestedSpecialty} '
                                      '(${result.confidencePercent}%)',
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(ctx),
                                child: const Text('OK'),
                              ),
                            ],
                          ),
                        );
                      },
                      child: const Text('AI Test karein'),
                    ),
                    const Text(
                      'Key sirf is phone par save hoti hai. '
                      'Get a key: aistudio.google.com/app/apikey',
                      style: TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'Admin Account',
                      style:
                          TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                    ),
                    const Text(
                      'Sirf ek admin hai. Password yahan se change karein.',
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () => _showChangePassword(context),
                      icon: const Icon(Icons.lock_reset),
                      label: const Text('Password Change karein'),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(52),
                        foregroundColor: const Color(0xFF0F766E),
                      ),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () async {
                        await AdminAuth.signOut();
                        if (context.mounted) {
                          Navigator.pushNamedAndRemoveUntil(
                            context,
                            '/',
                            (_) => false,
                          );
                        }
                      },
                      icon: const Icon(Icons.logout),
                      label: const Text('Logout'),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(52),
                        foregroundColor: Colors.red,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Doctors',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: () => _showDoctorForm(context, null),
                  icon: const Icon(Icons.add),
                  label: const Text('Add Doctor'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ...provider.doctors.map(
              (d) => Card(
                child: ListTile(
                  title: Text(d.name),
                  subtitle: Text(
                    '${d.specialty} • ${d.locationLabel}\n'
                    '${d.feeLabel} • Assistant: ${d.assistantName}',
                  ),
                  isThreeLine: true,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () => _showDoctorForm(context, d),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () async {
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: Text('${d.name} delete karein?'),
                              actions: [
                                TextButton(
                                  onPressed: () =>
                                      Navigator.pop(context, false),
                                  child: const Text('Cancel'),
                                ),
                                TextButton(
                                  onPressed: () =>
                                      Navigator.pop(context, true),
                                  child: const Text(
                                    'Delete',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                ),
                              ],
                            ),
                          );
                          if (ok == true && mounted) {
                            context
                                .read<BookingProvider>()
                                .deleteDoctor(d.id);
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Payment Accounts',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ...provider.paymentAccounts.entries.map(
              (e) => Card(
                child: ListTile(
                  title: Text(e.key),
                  subtitle: Text(e.value),
                  trailing: IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () => _showAccountForm(context, e.key, e.value),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Icon / Logo: user jo icon aur logo bhejega, wo '
              'assets/images/ me rakha jayega aur app icon / '
              'welcome screen par use hoga.',
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showChangePassword(BuildContext context) async {
    final current = TextEditingController();
    final next = TextEditingController();
    final confirm = TextEditingController();
    String? error;
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('Password Change karein'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: current,
                obscureText: true,
                decoration:
                    const InputDecoration(labelText: 'Current password'),
              ),
              TextField(
                controller: next,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'New password'),
              ),
              TextField(
                controller: confirm,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'New password dobara',
                ),
              ),
              if (error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                if (next.text.length < 6) {
                  setDialogState(
                    () => error = 'New password kam se kam 6 characters ka ho.',
                  );
                  return;
                }
                if (next.text != confirm.text) {
                  setDialogState(
                    () => error = 'New password aur confirm same nahi hain.',
                  );
                  return;
                }
                final changed = await AdminAuth.changePassword(
                  current.text,
                  next.text,
                );
                if (!changed) {
                  setDialogState(
                    () => error = 'Current password galat hai.',
                  );
                  return;
                }
                if (dialogContext.mounted) {
                  Navigator.pop(dialogContext, true);
                }
              },
              child: const Text('Change'),
            ),
          ],
        ),
      ),
    );
    if (ok == true && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Admin password change ho gaya.')),
      );
    }
  }

  Future<void> _showAccountForm(
    BuildContext context,
    String method,
    String current,
  ) async {
    final controller = TextEditingController(text: current);
    final value = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('$method account'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Account details'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (value != null && value.isNotEmpty && context.mounted) {
      await context.read<BookingProvider>().updatePaymentAccount(method, value);
    }
  }

  Future<void> _showDoctorForm(BuildContext context, Doctor? existing) async {
    final name = TextEditingController(text: existing?.name ?? '');
    final clinic = TextEditingController(text: existing?.clinic ?? '');
    final location =
        TextEditingController(text: existing?.location ?? '');
    final city = TextEditingController(text: existing?.city ?? 'Dera Ismail Khan');
    final fee = TextEditingController(
      text: existing == null ? '' : existing.feePkr.toString(),
    );
    final rating = TextEditingController(
      text: existing == null ? '4.8' : existing.rating.toString(),
    );
    final experience = TextEditingController(
      text: existing == null ? '' : existing.experienceYears.toString(),
    );
    final assistantName =
        TextEditingController(text: existing?.assistantName ?? '');
    final mapsLink = TextEditingController(text: existing?.mapsLink ?? '');
    String specialty = existing?.specialty ?? specialties.first;

    final saved = await showDialog<Doctor>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text(existing == null ? 'Add Doctor' : 'Edit Doctor'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(labelText: 'Doctor name'),
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: specialty,
                  items: specialties
                      .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                      .toList(),
                  onChanged: (v) =>
                      setDialogState(() => specialty = v ?? specialty),
                  decoration: const InputDecoration(labelText: 'Specialty'),
                ),
                TextField(
                  controller: clinic,
                  decoration:
                      const InputDecoration(labelText: 'Clinic name'),
                ),
                TextField(
                  controller: location,
                  decoration: const InputDecoration(
                    labelText: 'Location / Address',
                    hintText: 'Main Bazaar, Dera Ismail Khan',
                  ),
                ),
                TextField(
                  controller: mapsLink,
                  decoration: const InputDecoration(
                    labelText: 'Google Maps link (optional)',
                  ),
                ),
                TextField(
                  controller: city,
                  decoration: const InputDecoration(labelText: 'City'),
                ),
                TextField(
                  controller: fee,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: 'Fee (PKR)'),
                ),
                TextField(
                  controller: rating,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: 'Rating (0–5)'),
                ),
                TextField(
                  controller: experience,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Experience (years)',
                  ),
                ),
                TextField(
                  controller: assistantName,
                  decoration: const InputDecoration(
                    labelText: 'Assistant name',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                if (name.text.trim().isEmpty) return;
                Navigator.pop(
                  dialogContext,
                  Doctor(
                    id: existing?.id ??
                        'dr${DateTime.now().millisecondsSinceEpoch}',
                    name: name.text.trim(),
                    specialty: specialty,
                    clinic: clinic.text.trim(),
                    city: city.text.trim(),
                    feePkr: int.tryParse(fee.text.trim()) ?? 0,
                    rating: double.tryParse(rating.text.trim()) ?? 0,
                    experienceYears:
                        int.tryParse(experience.text.trim()) ?? 0,
                    assistantName: assistantName.text.trim().isEmpty
                        ? 'Clinic Assistant'
                        : assistantName.text.trim(),
                    location: location.text.trim(),
                    mapsLink: mapsLink.text.trim(),
                  ),
                );
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
    if (saved != null && context.mounted) {
      final provider = context.read<BookingProvider>();
      if (existing == null) {
        provider.addDoctor(saved);
      } else {
        provider.updateDoctor(saved);
      }
    }
  }
}
