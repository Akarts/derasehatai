import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/booking_provider.dart';
import 'screens/patient/welcome_screen.dart';
import 'screens/role_screen.dart';
import 'services/firestore_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Firebase: works when google-services.json (Android) /
  // GoogleService-Info.plist (iOS) is added — see
  // firebase-setup-guide.md. Without it, initializeApp throws
  // and the app keeps running offline on local data, so the
  // test build still works.
  try {
    await Firebase.initializeApp();
    FirestoreService.isConfigured = true;
  } catch (_) {
    FirestoreService.isConfigured = false;
  }
  runApp(const DeraSehatAiApp());
}

class DeraSehatAiApp extends StatelessWidget {
  const DeraSehatAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => BookingProvider(),
      child: MaterialApp(
        title: 'DeraSehatAi',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF0F766E), // teal
            primary: const Color(0xFF0F766E),
            secondary: const Color(0xFF059669),
          ),
          scaffoldBackgroundColor: const Color(0xFFF0FDF9),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF0F766E),
            foregroundColor: Colors.white,
            centerTitle: true,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0F766E),
              foregroundColor: Colors.white,
              minimumSize: const Size.fromHeight(52),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              textStyle: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 16,
            ),
          ),
          cardTheme: CardThemeData(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
        ),
        home: const RoleScreen(),
        routes: {
          '/welcome': (_) => const WelcomeScreen(),
        },
      ),
    );
  }
}
