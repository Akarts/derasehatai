/// Gemini API key for DeraSehatAi.
///
/// HOW TO ADD YOUR KEY (two ways, either works):
/// 1. In the app: open Admin > Gemini API Key, paste your key, Save.
///    It is stored only on that phone (SharedPreferences).
/// 2. In code: replace the placeholder below, then rebuild the APK.
///
/// Get a key at https://aistudio.google.com/app/apikey
/// Never ship a real key in a production app — in production call
/// Gemini from your own backend / Firebase Function instead, so the
/// key is not inside the APK.
class AppConfig {
  static const String geminiApiKey = 'YOUR_GEMINI_API_KEY';
}
