import 'dart:convert';

/// A doctor in the DeraSehatAi directory.
/// Doctors are managed in the Admin panel and saved on the phone;
/// [sampleDoctors] is only the first-run seed.
class Doctor {
  const Doctor({
    required this.id,
    required this.name,
    required this.specialty,
    required this.clinic,
    required this.city,
    required this.feePkr,
    required this.rating,
    required this.experienceYears,
    this.assistantName = 'Clinic Assistant',
    this.location = '',
    this.mapsLink = '',
  });

  final String id;
  final String name;
  final String specialty;
  final String clinic;
  final String city;
  final int feePkr;
  final double rating;
  final int experienceYears;
  final String assistantName;

  /// Clinic address / location, e.g. "Main Bazaar, Dera Ismail Khan".
  final String location;

  /// Optional Google Maps link for the clinic.
  final String mapsLink;

  String get feeLabel => 'Rs. ${feePkr.toString()}';

  /// Short location line for the doctor card.
  String get locationLabel =>
      location.isNotEmpty ? location : clinic;

  Doctor copyWith({
    String? name,
    String? specialty,
    String? clinic,
    String? city,
    int? feePkr,
    double? rating,
    int? experienceYears,
    String? assistantName,
    String? location,
    String? mapsLink,
  }) {
    return Doctor(
      id: id,
      name: name ?? this.name,
      specialty: specialty ?? this.specialty,
      clinic: clinic ?? this.clinic,
      city: city ?? this.city,
      feePkr: feePkr ?? this.feePkr,
      rating: rating ?? this.rating,
      experienceYears: experienceYears ?? this.experienceYears,
      assistantName: assistantName ?? this.assistantName,
      location: location ?? this.location,
      mapsLink: mapsLink ?? this.mapsLink,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'specialty': specialty,
        'clinic': clinic,
        'city': city,
        'feePkr': feePkr,
        'rating': rating,
        'experienceYears': experienceYears,
        'assistantName': assistantName,
        'location': location,
        'mapsLink': mapsLink,
      };

  factory Doctor.fromJson(Map<String, dynamic> json) => Doctor(
        id: json['id'] as String? ?? '',
        name: json['name'] as String? ?? '',
        specialty: json['specialty'] as String? ?? 'General Physician',
        clinic: json['clinic'] as String? ?? '',
        city: json['city'] as String? ?? '',
        feePkr: (json['feePkr'] as num?)?.toInt() ?? 0,
        rating: (json['rating'] as num?)?.toDouble() ?? 0,
        experienceYears:
            (json['experienceYears'] as num?)?.toInt() ?? 0,
        assistantName:
            json['assistantName'] as String? ?? 'Clinic Assistant',
        location: json['location'] as String? ?? '',
        mapsLink: json['mapsLink'] as String? ?? '',
      );

  static List<Doctor> listFromJson(String raw) {
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded
        .map((e) => Doctor.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  static String listToJson(List<Doctor> doctors) =>
      jsonEncode(doctors.map((d) => d.toJson()).toList());
}

/// Sample doctors — first-run seed only. The Admin panel can
/// add, edit and delete doctors; those changes replace this list.
const List<Doctor> sampleDoctors = [
  Doctor(
    id: 'dr-ahmed',
    name: 'Dr. Ahmed Raza',
    specialty: 'General Physician',
    clinic: 'Sehat Clinic, Main Bazaar',
    city: 'Dera Ismail Khan',
    feePkr: 1500,
    rating: 4.8,
    experienceYears: 12,
    assistantName: 'Bilal (Assistant)',
    location: 'Main Bazaar, Dera Ismail Khan',
  ),
  Doctor(
    id: 'dr-fatima',
    name: 'Dr. Fatima Khan',
    specialty: 'Pediatrician',
    clinic: 'Children Care Clinic',
    city: 'Dera Ismail Khan',
    feePkr: 1800,
    rating: 4.9,
    experienceYears: 10,
    assistantName: 'Ayesha (Assistant)',
    location: 'Circular Road, Dera Ismail Khan',
  ),
  Doctor(
    id: 'dr-usman',
    name: 'Dr. Usman Ali',
    specialty: 'Gastroenterologist',
    clinic: 'Digestive Care Centre',
    city: 'Dera Ismail Khan',
    feePkr: 2000,
    rating: 4.7,
    experienceYears: 14,
    assistantName: 'Bilal (Assistant)',
    location: 'Hospital Road, Dera Ismail Khan',
  ),
  Doctor(
    id: 'dr-sana',
    name: 'Dr. Sana Malik',
    specialty: 'Dermatologist',
    clinic: 'Skin & Care Clinic',
    city: 'Dera Ismail Khan',
    feePkr: 1600,
    rating: 4.8,
    experienceYears: 9,
    assistantName: 'Ayesha (Assistant)',
    location: 'Main Bazaar, Dera Ismail Khan',
  ),
  Doctor(
    id: 'dr-hassan',
    name: 'Dr. Hassan Iqbal',
    specialty: 'Dentist',
    clinic: 'Bright Smile Dental',
    city: 'Dera Ismail Khan',
    feePkr: 1600,
    rating: 4.6,
    experienceYears: 8,
    assistantName: 'Bilal (Assistant)',
    location: 'Circular Road, Dera Ismail Khan',
  ),
  Doctor(
    id: 'dr-maryam',
    name: 'Dr. Maryam Siddiqui',
    specialty: 'Gynecologist',
    clinic: 'Mother Care Clinic',
    city: 'Dera Ismail Khan',
    feePkr: 2000,
    rating: 4.9,
    experienceYears: 15,
    assistantName: 'Ayesha (Assistant)',
    location: 'Hospital Road, Dera Ismail Khan',
  ),
];

/// Specialties offered in the Admin doctor form.
const List<String> specialties = [
  'General Physician',
  'Pediatrician',
  'Gastroenterologist',
  'Dermatologist',
  'Dentist',
  'Gynecologist',
];
