/// Result of the Gemini AI triage step.
///
/// The AI never diagnoses. It only summarises what the patient said,
/// asks follow-up questions, and suggests which specialist to see.
class TriageResult {
  const TriageResult({
    required this.summary,
    required this.suggestedSpecialty,
    required this.confidencePercent,
    required this.followUpQuestions,
    this.isEmergency = false,
    this.isDemo = false,
  });

  final String summary;
  final String suggestedSpecialty;
  final int confidencePercent;
  final List<String> followUpQuestions;

  /// Red-flag symptoms (chest pain, breathing trouble, etc.).
  final bool isEmergency;

  /// True when this answer came from the offline keyword mock,
  /// not from Gemini — e.g. no key, or the Gemini call failed.
  final bool isDemo;
}
