import 'doctor.dart';

enum BookingStatus {
  requested, // Patient sent a request, Assistant has not picked a time yet.
  timeOffered, // Assistant offered a time, patient must pay.
  paymentSent, // Patient uploaded screenshot + Transaction ID.
  confirmed, // Assistant verified payment and approved.
  rejected, // Assistant rejected the request or the payment.
}

extension BookingStatusLabel on BookingStatus {
  String get label {
    switch (this) {
      case BookingStatus.requested:
        return 'Request sent';
      case BookingStatus.timeOffered:
        return 'Time offered — pay now';
      case BookingStatus.paymentSent:
        return 'Payment sent — waiting for Assistant';
      case BookingStatus.confirmed:
        return 'Confirmed';
      case BookingStatus.rejected:
        return 'Rejected';
    }
  }
}

class Booking {
  Booking({
    required this.id,
    required this.doctor,
    required this.patientName,
    required this.patientAge,
    required this.symptoms,
    required this.aiSummary,
    required this.suggestedSpecialty,
    this.status = BookingStatus.requested,
    this.offeredTime,
    this.tokenNumber,
    this.paymentMethod,
    this.transactionId,
    this.detectedAmount,
    this.screenshotPath,
    this.rejectionReason,
  });

  final String id;
  final Doctor doctor;
  final String patientName;
  final int patientAge;
  final String symptoms;
  final String aiSummary;
  final String suggestedSpecialty;
  BookingStatus status;
  String? offeredTime;
  int? tokenNumber;
  String? paymentMethod;
  /// Transaction ID auto-detected by AI from the payment screenshot.
  /// The patient never types it.
  String? transactionId;
  /// Amount auto-detected by AI from the payment screenshot, if any.
  String? detectedAmount;
  String? screenshotPath;
  String? rejectionReason;

  Booking copyWith({
    BookingStatus? status,
    String? offeredTime,
    int? tokenNumber,
    String? paymentMethod,
    String? transactionId,
    String? detectedAmount,
    String? screenshotPath,
    String? rejectionReason,
  }) {
    return Booking(
      id: id,
      doctor: doctor,
      patientName: patientName,
      patientAge: patientAge,
      symptoms: symptoms,
      aiSummary: aiSummary,
      suggestedSpecialty: suggestedSpecialty,
      status: status ?? this.status,
      offeredTime: offeredTime ?? this.offeredTime,
      tokenNumber: tokenNumber ?? this.tokenNumber,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      transactionId: transactionId ?? this.transactionId,
      detectedAmount: detectedAmount ?? this.detectedAmount,
      screenshotPath: screenshotPath ?? this.screenshotPath,
      rejectionReason: rejectionReason ?? this.rejectionReason,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'doctor': doctor.toJson(),
        'patientName': patientName,
        'patientAge': patientAge,
        'symptoms': symptoms,
        'aiSummary': aiSummary,
        'suggestedSpecialty': suggestedSpecialty,
        'status': status.name,
        'offeredTime': offeredTime,
        'tokenNumber': tokenNumber,
        'paymentMethod': paymentMethod,
        'transactionId': transactionId,
        'detectedAmount': detectedAmount,
        'screenshotPath': screenshotPath,
        'rejectionReason': rejectionReason,
        'createdAt': DateTime.now().millisecondsSinceEpoch,
      };

  factory Booking.fromJson(Map<String, dynamic> json) {
    final doctorJson = json['doctor'];
    return Booking(
      id: json['id'] as String? ?? '',
      doctor: doctorJson is Map<String, dynamic>
          ? Doctor.fromJson(doctorJson)
          : sampleDoctors.first,
      patientName: json['patientName'] as String? ?? '',
      patientAge: (json['patientAge'] as num?)?.toInt() ?? 0,
      symptoms: json['symptoms'] as String? ?? '',
      aiSummary: json['aiSummary'] as String? ?? '',
      suggestedSpecialty: json['suggestedSpecialty'] as String? ?? '',
      status: BookingStatus.values.firstWhere(
        (s) => s.name == json['status'],
        orElse: () => BookingStatus.requested,
      ),
      offeredTime: json['offeredTime'] as String?,
      tokenNumber: (json['tokenNumber'] as num?)?.toInt(),
      paymentMethod: json['paymentMethod'] as String?,
      transactionId: json['transactionId'] as String?,
      detectedAmount: json['detectedAmount'] as String?,
      screenshotPath: json['screenshotPath'] as String?,
      rejectionReason: json['rejectionReason'] as String?,
    );
  }
}
