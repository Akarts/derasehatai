# DeraSehatAi — Flutter MVP

**DeraSehatAi** — Doctor AI appointment app for a Pakistani city.
Patient apni takleef Urdu / Roman Urdu / English me likh kar ya bol kar
batata hai, Gemini AI sahi specialist suggest karta hai, doctor ka Assistant
time select karta hai, patient JazzCash / Easypaisa se manual payment
karta hai (screenshot + Transaction ID), aur Assistant verify karke booking
confirm karta hai.

> Ye MVP hai — design prototype (12 screens) ka working Flutter version.
> Koi real API key, Firebase config ya secret is repo me nahi hai.

## Tech Stack — Kis cheez me bana hai?

| Hissa | Technology |
|---|---|
| App (Android + iPhone, ek code) | **Flutter (Dart)** |
| Backend / Database / Login | **Firebase** — Firestore, Auth, Storage, Messaging (stubs ready, wiring TODO) |
| AI triage | **Google Gemini API** (`google_generative_ai`) |
| State | **Provider** (in-memory, offline demo) |
| Voice input | `speech_to_text` |
| Screenshot upload | `image_picker` |

## How to Run — Chalane ka tareeqa

```bash
# 1. Flutter SDK install karein (https://docs.flutter.dev/get-started/install)
flutter --version

# 2. Is folder me jayein
cd sehatai-flutter

# 3. Dependencies install karein
flutter pub get

# 4. App chalaye (phone / emulator connect karke)
flutter run
```

> Note: Is machine par Flutter install nahi tha, isliye `flutter analyze`
> nahi chal saka. Upar wale steps kisi bhi machine par jahan Flutter
> ho, wahan chalenge.

## APK kaise banayein — GitHub Actions (laptop nahi chahiye)

Is project me `.github/workflows/build-apk.yml` pehle se hai:

1. GitHub par free account banayein, naya repository banayein
2. Is project ki zip upload karein (ya files push karein)
3. Repository ke **Actions** tab me build khud chalegi
4. Build complete hone par **Artifacts → sehatai-apk** se
   `app-release.apk` download karein, phone par install karein

Codemagic se bhi yehi zip use hoti hai — dono me se jo asaan lage.

## Pehle kya add karna hai? (Placeholders)

### 1. Gemini API Key
**App me:** Role screen → **Admin** → Gemini API Key field me key paste karein aur Save karein (key sirf us phone par save hoti hai).
**Ya code me:** File: `lib/config.dart`
```dart
static const String geminiApiKey = 'YOUR_GEMINI_API_KEY';
```
Key yahan se lein: https://aistudio.google.com/app/apikey
Key ke baghair bhi app chalegi — local mock triage use hoga
(pait dard → Gastroenterologist, bukhar/khansi → General Physician,
daant → Dentist, jild → Dermatologist, bacha → Pediatrician).
**Production me key ko app me hardcode na karein** — apne backend /
Firebase Function se Gemini call karein.

### 2. Firebase Config
1. https://console.firebase.google.com par project banayein: `DeraSehatAi`
2. Android app add karein, package: `sehatai.app`
3. `google-services.json` ko `android/app/` me rakhein
4. iOS app add karein, `GoogleService-Info.plist` ko `ios/Runner/` me rakhein
5. `lib/services/firestore_service.dart` ke TODOs implement karein aur
   `main.dart` me `Firebase.initializeApp()` uncomment karein

Firebase ke baghair bhi app poori tarah chalti hai — sample doctors
aur bookings in-memory hain (`lib/providers/booking_provider.dart`).

## Admin Panel — Doctors kaise add karein?

Role screen → **"Main Admin / Developer hoon"** → Admin Login
- **Doctors:** Add Doctor dabayein — naam, specialty, clinic, **location / address**, Google Maps link (optional), city, fee, rating, experience, Assistant name. Kisi bhi doctor ko Edit ya Delete bhi kar sakte hain. Changes phone par save ho jati hain, patient ko foran nayi doctor list dikhegi.
- **Payment Accounts:** JazzCash / Easypaisa / Bank account numbers yahan se change karein — payment screen par naye numbers dikhenge.
- **Gemini API Key:** Yahan key add karein — AI triage aur Transaction ID detection dono isi key se chalenge.
- **Admin Account:** Admin panel kholne ke liye login zaroori hai. Pehli dafa aap apna ek Admin account banayenge (username + password, aap ki marzi) — sirf yehi ek admin hoga, doosra nahi ban sakta. Password bhool gaye to app data clear karna parega. Password Admin panel me Change bhi kar sakte hain.
- **Icon / Logo:** User jo icon aur logo bhejega, wo `assets/images/` me rakha jayega aur welcome screen / app icon par use hoga.

## How to Test — Test kaise karein

### Patient flow
1. App kholein → **"Main Patient hoon"**
2. **AI se puchein** → zuban select karein (Urdu / Roman Urdu / English)
3. Likh kar ya bol kar takleef batayein, jaise:
   `Pait me 3 din se dard hai, bukhar bhi hai.`
4. **AI se puchein** dabayein → AI summary + Gastroenterologist (92%) dikhega
5. Doctor select karein → naam/umar likhein → **Request Assistant ko bhejein**
6. Payment screen: JazzCash select karein, screenshot upload karein —
   AI screenshot se Transaction ID aur amount khud detect karke dikhayega.
   Transaction ID type karne ki zaroorat nahi.
7. **Payment bhej di** → status screen dikhegi (waiting for Assistant)

### Voice input
Voice ke liye microphone permission zaroori hai — AndroidManifest me `RECORD_AUDIO` permission hai aur app pehli dafa khulte hi microphone permission mangti hai. Agar aap ne deny kar di ho to Symptom screen par mic dabate hi dobara mangegi, aur permanently denied ho to Settings > Apps > DeraSehatAi > Permissions se Microphone on karna parega. Urdu select ho to `ur-PK` locale, warna English locale use hota hai.

### Assistant flow
1. App dobara kholein (ya role change karein) → **"Main Doctor ka Assistant hoon"**
2. **Inbox** me request dikhegi, AI summary ke saath
3. Time slot select karein (jaise `Today, 5:30 PM`) — patient ko
   payment ka message jayega
4. Payment aane par **Payment verify karein** dabayein — screenshot
   aur Transaction ID dikhega
5. **Approve** dabayein → booking Confirm, Token # issue (jaise #14)
6. **Confirmed** tab me booking dikhegi

> Demo shortcut: Patient flow me request bhejte hi Assistant ka time
> (`Today, 5:30 PM`) auto-offer ho jata hai taake payment screen
> foran test ho sake. Real app me ye Assistant ke phone se hoga.
> Ek demo booking pehle se Assistant inbox me hai (Ahmed, payment sent).

## Project Structure

```
sehatai-flutter/
├── pubspec.yaml                 # dependencies, package sehatai.app
├── lib/
│   ├── main.dart                # App entry, teal theme, Provider setup
│   ├── models/
│   │   ├── doctor.dart          # Doctor + 6 sample doctors (PKR fees)
│   │   ├── booking.dart         # Booking + BookingStatus (requested → confirmed)
│   │   └── triage_result.dart   # AI triage result
│   ├── services/
│   │   ├── gemini_service.dart  # Gemini API + mock fallback triage
│   │   └── firestore_service.dart # Firestore stubs (TODO for production)
│   ├── providers/
│   │   └── booking_provider.dart # In-memory state, sample data
│   ├── screens/
│   │   ├── role_screen.dart     # Patient ya Assistant select karein
│   │   ├── patient/
│   │   │   ├── welcome_screen.dart       # Language selection
│   │   │   ├── symptom_screen.dart       # Voice/text + AI chat
│   │   │   ├── doctor_list_screen.dart   # AI-suggested doctors
│   │   │   ├── booking_screen.dart       # Request Assistant ko bhejein
│   │   │   ├── payment_screen.dart       # JazzCash/Easypaisa + screenshot, AI Txn ID detect
│   │   │   ├── confirmation_screen.dart  # Token # wali confirmation
│   │   │   └── patient_home_screen.dart  # Bottom nav: Home / My Bookings
│   │   └── pa/
│   │       ├── pa_home_screen.dart          # Inbox, time slot, Confirmed list
│   │       └── pa_payment_verify_screen.dart # Screenshot + Txn ID, Approve/Reject
│   └── widgets/
│       └── doctor_card.dart     # DoctorCard, StatusChip, AiDisclaimer
├── android/app/                 # AndroidManifest, MainActivity (package sehatai.app)
├── ios/Runner/                  # AppDelegate, Info.plist
└── README.md
```

## Important — AI Disclaimer

AI **diagnosis nahi deta aur dawai nahi batata**. Sirf patient ki
baat ko samajh kar sahi specialist suggest karta hai. Emergency
alamat (seene me dard, saans rukna) par app foran hospital jane ka
alert dikhata hai. Ye disclaimer app ki har AI screen par hai.

## TODO for Production — Abhi kya baqi hai

- [ ] Real Firebase wiring (Firestore rules, Auth phone OTP, Storage upload)
- [ ] Gemini key ko backend / Firebase Function me shift karna
- [ ] Push notifications (FCM) — Assistant ko nayi request, patient ko time/payment alert
- [ ] WhatsApp notification (optional) Assistant ke liye
- [x] Developer Admin panel (doctors, locations, payment accounts, Gemini key) — in-app, no PIN yet; production me PIN / Firebase Auth admin check add karein
- [ ] Doctor onboarding
- [ ] Payment fraud check (duplicate Transaction ID rokna)
- [ ] Play Store / App Store publishing (signing keys, privacy policy)
