// Smoke test: the app launches to the role-selection screen.
import 'package:flutter_test/flutter_test.dart';

import 'package:sehatai/main.dart';

void main() {
  testWidgets('DeraSehatAi launches to role selection', (WidgetTester tester) async {
    await tester.pumpWidget(const DeraSehatAiApp());

    // The DeraSehatAi name is now in the logo image, not a Text widget.
    expect(find.text('AI se sahi doctor, asaan booking'), findsOneWidget);
    expect(find.text('Developed By: Muhammad Arsalan Kakar'), findsOneWidget);
    expect(find.text('Main Patient hoon'), findsOneWidget);
    expect(find.text('Main Doctor ka Assistant hoon'), findsOneWidget);
    expect(find.text('Main Admin / Developer hoon'), findsOneWidget);
  });
}
