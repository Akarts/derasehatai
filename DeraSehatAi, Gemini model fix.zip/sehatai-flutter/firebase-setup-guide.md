# DeraSehatAi — Firebase Backend Setup Guide

This is what turns the test app (everything saved on one phone)
into the real app (one admin, same doctors and bookings on every
phone, Gemini key kept on the server, never in the app).

**Time:** about 20–30 minutes, mostly in the Firebase console.
**Cost:** Firebase Spark (free) is enough to start. Cloud Functions
need the Blaze (pay-as-you-go) plan because they call Gemini
outside Google — Gemini's free tier usually keeps this at $0 for
a small clinic, but check usage in the console.

## What the backend gives you

| Thing | Before (local) | After (Firebase) |
|---|---|---|
| Admin account | Created on each phone, anyone can create one | One Firebase Auth user (your email), listed in Firestore `admins/` — only that user can open the Admin panel, on any phone |
| Doctors | Saved on one phone only | Firestore `doctors` — you add one, every phone sees it |
| Payment accounts | Saved on one phone only | Firestore `settings/app` — shared |
| Bookings | On one phone only | Firestore `bookings` — patient on one phone, Assistant on another |
| Gemini API key | In the app / on the phone | Cloud Secret `GEMINI_API_KEY` — the app never sees it |

## Step 1 — Create the Firebase project (you, in the browser)

1. Go to https://console.firebase.google.com and sign in with your
   Gmail (use mohammadarsalan93@gmail.com if you want it to match
   the developer email).
2. **Add project** → name it `DeraSehatAi` → Continue. Google
   Analytics: off is fine.
3. In the project, go to **Build → Authentication → Get started →
   Sign-in method → Email/Password → Enable → Save.**
4. Go to **Build → Firestore Database → Create database →**
   Start in **production mode** → pick a location (e.g.
   `asia-south1` / Mumbai, closest to Pakistan) → Enable.
5. Go to **Build → Storage → Get started** (default rules are fine
   for now).

## Step 2 — Add the Android app and download the config file

1. In the Firebase console, project overview → **Add app → Android**.
2. Android package name: `com.aksofts.derasehatai` (exactly this — this is the package in your google-services.json).
   App nickname: `DeraSehatAi`.
3. Download **`google-services.json`**.
4. Put that file in the project at:
   `sehatai-flutter/android/app/google-services.json`
   (next to `build.gradle.kts`). Do NOT paste its contents in chat —
   send it as a file if you want me to place it for you.
5. (iPhone later: same flow, **Add app → iOS**, bundle id
   `sehatai.app`, download `GoogleService-Info.plist` into
   `sehatai-flutter/ios/Runner/`.)

## Step 3 — Create the ONE admin user

1. **Authentication → Users → Add user.**
   Email: your admin email (e.g. mohammadarsalan93@gmail.com).
   Password: choose a strong password and write it down.
   This is the ONLY admin login.
2. Copy that user's **UID** (click the user to see it).
3. **Firestore Database → Start collection →** Collection ID:
   `admins` → Document ID: paste the UID → add a field:
   `email` (string) = your admin email → Save.
   Only a user whose UID is in `admins/` can write doctors /
   settings / bookings. Everyone else is locked out by the rules
   in `firestore.rules`.

## Step 4 — Publish the security rules

On your laptop, with the Firebase CLI installed
(`npm install -g firebase-tools`, then `firebase login`):

```powershell
cd E:\src\sehatai-flutter
firebase use --add   # pick the DeraSehatAi project
firebase deploy --only firestore:rules
```

Or in the console: **Firestore → Rules →** paste the contents of
`firestore.rules` from this project → Publish.

## Step 5 — Seed the doctors (first time, from the Admin panel)

This step needs NO work in the Firebase console. It just means:

1. Rebuild the APK with the Firebase config in place (see below)
   and install it on your phone. **Uninstall the old app first**,
   so it starts clean.
2. Open the app, tap **Admin**, and log in with the admin email +
   password from Step 3.
3. The first time you open the Admin panel, the app automatically
   uploads the 6 sample doctors to Firestore (only if the
   `doctors` collection is still empty — it never overwrites
   doctors you already added).
4. Now edit those sample doctors in the panel, or delete them and
   add your real doctors with their clinic locations. Every change
   is saved to Firestore, so **every phone sees the same list**
   straight away. That is the whole point of Step 5 — you do it
   once, in the app, not in the console.

If an edit in the Admin panel fails with a permission error, Step 4
(the rules) has not been published yet — do that first, then retry.

## Step 6 — Gemini via Cloud Functions (optional, for the secure key)

This is what keeps the Gemini key out of the app entirely.

1. In the Firebase console, **Upgrade to Blaze** (pay-as-you-go).
   Set a budget alert in **Billing** so you are never surprised.
2. On the laptop:
   ```powershell
   cd E:\src\sehatai-flutter\functions
   npm install
   cd ..
   firebase functions:secrets:set GEMINI_API_KEY
   # paste your Gemini key when asked (from aistudio.google.com/app/apikey)
   firebase deploy --only functions
   ```
3. Done — the app now calls `triageSymptoms` and
   `extractTransaction` in the cloud. If the functions are not
   deployed yet, the app falls back to the key in the Admin panel
   / `lib/config.dart`, and then to mock triage.

## Rebuild the APK

```powershell
$env:Path += ";E:\src\flutter\bin"
cd E:\src\sehatai-flutter
flutter pub get
flutter build apk --release
```

APK: `E:\src\sehatai-flutter\build\app\outputs\flutter-apk\app-release.apk`

## What I still need from you

- The `google-services.json` file (Step 2) — send it as a file
  and I will place it and rebuild the zip for you.
- Your admin email + that you created the admin user (Step 3).
  **Never send the admin password in chat.**
- Your Gemini API key, only when you set the Cloud Secret
  (Step 6) — paste it into the Firebase CLI prompt, not in chat.

## Files in this project for Firebase

- `lib/main.dart` — `Firebase.initializeApp()`, falls back offline
  when no config file is present.
- `lib/services/firestore_service.dart` — doctors, settings,
  bookings, Storage upload, admin check.
- `lib/providers/booking_provider.dart` — uses Firestore when
  configured, local data otherwise.
- `lib/screens/admin/admin_login_screen.dart` — Firebase Auth
  admin login when configured, local login otherwise.
- `lib/services/gemini_service.dart` — Cloud Functions first
  when Firebase is on, direct key / mock otherwise.
- `firestore.rules`, `firebase.json` — rules + deploy config.
- `functions/index.js`, `functions/package.json` — Gemini Cloud
  Functions (triage + Transaction ID).
