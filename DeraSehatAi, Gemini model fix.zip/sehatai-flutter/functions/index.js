// DeraSehatAi Cloud Functions (2nd gen).
// The Gemini API key is stored as a Cloud Secret named GEMINI_API_KEY
// — it is NEVER in the app or in this repo. Set it with:
//   firebase functions:secrets:set GEMINI_API_KEY
// Deploy with:
//   firebase deploy --only functions
// NOTE: calling Gemini from Cloud Functions needs the Blaze
// (pay-as-you-go) plan in Firebase, because it makes an outbound
// network call. Gemini's free tier usually keeps this at $0 for
// a small clinic app, but check usage in the Firebase console.

const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const geminiKey = defineSecret('GEMINI_API_KEY');

function model() {
  return new GoogleGenerativeAI(geminiKey.value())
    // gemini-1.5-flash is retired by Google (404) — use 3.5-flash.
    .getGenerativeModel({ model: 'gemini-3.5-flash' });
}

function pick(text, label) {
  for (const line of String(text || '').split('\n')) {
    if (line.toUpperCase().startsWith(label)) {
      const v = line.slice(label.length).trim();
      return v.toUpperCase() === 'NOT_FOUND' ? '' : v;
    }
  }
  return '';
}

// Patient symptoms -> specialist. No diagnosis, no prescription.
exports.triageSymptoms = onCall(
  { secrets: [geminiKey] },
  async (request) => {
    const symptoms = String(request.data?.symptoms || '').trim();
    const age = Number(request.data?.age || 0);
    if (!symptoms) throw new HttpsError('invalid-argument', 'symptoms required');
    const res = await model().generateContent(
      `You are a medical triage assistant for a clinic booking app in Pakistan.
The patient wrote (in Urdu, Roman Urdu or English): "${symptoms}".
Patient age: ${age}.
Reply in exactly this format, in simple English:
SUMMARY: <one short summary of the problem>
SPECIALTY: <one of: General Physician, Pediatrician, Gastroenterologist, Dermatologist, Dentist, Gynecologist, Orthopedic Surgeon>
CONFIDENCE: <0-100>
QUESTION 1: <a useful follow-up question>
QUESTION 2: <a useful follow-up question>
EMERGENCY: <yes or no — yes only for chest pain, breathing trouble, unconsciousness, heavy bleeding, or a broken bone>
Do NOT give a diagnosis. Do NOT prescribe medicine. This is only to choose the right specialist.`
    );
    const text = res.response.text();
    return {
      summary: pick(text, 'SUMMARY:') || symptoms,
      specialty: pick(text, 'SPECIALTY:') || 'General Physician',
      confidence: Math.min(100, Math.max(0, parseInt(pick(text, 'CONFIDENCE:')) || 70)),
      questions: [pick(text, 'QUESTION 1:'), pick(text, 'QUESTION 2:')].filter(Boolean),
      isEmergency: pick(text, 'EMERGENCY:').toLowerCase().startsWith('y'),
    };
  }
);

// Payment screenshot (base64 JPEG) -> Transaction ID, amount, method.
exports.extractTransaction = onCall(
  { secrets: [geminiKey] },
  async (request) => {
    const imageBase64 = String(request.data?.imageBase64 || '');
    if (!imageBase64) throw new HttpsError('invalid-argument', 'imageBase64 required');
    const res = await model().generateContent([
      { text: `This is a payment receipt screenshot from JazzCash, Easypaisa or a bank in Pakistan. Read it and reply in exactly this format, one item per line, nothing else:
TRANSACTION_ID: <the transaction / reference / TID number, or NOT_FOUND>
AMOUNT: <the amount paid, e.g. Rs. 1600, or NOT_FOUND>
METHOD: <JazzCash, Easypaisa or Bank Transfer, or NOT_FOUND>
DATE: <the payment date if shown, or NOT_FOUND>` },
      { inlineData: { mimeType: 'image/jpeg', data: imageBase64 } },
    ]);
    const text = res.response.text();
    const id = pick(text, 'TRANSACTION_ID:');
    if (!id) return null;
    return {
      transactionId: id,
      amount: pick(text, 'AMOUNT:'),
      method: pick(text, 'METHOD:'),
      date: pick(text, 'DATE:'),
    };
  }
);
